% clear;clc
format short e
m = 1e4;n = 1e4;
q = 1;pic = 0;
for s = 5:6
    tic
    if s == 5
        [u,Err,E,M,P,H,x,t] = SAV_RK_Newton(m,n,3,q,pic);
    elseif s == 6
        [u,Err,E,M,P,H,x,t] = SAV_CN(m,n,s,q,pic);
    else
        for i = 1:length(n)
            [u,Err,E,M,P,H,x,t] = IEQ_RK(m,n,s,q,pic);
        end
    end
    Max(s,i) = max(max(Err));
    CPU_time(s,i) = toc;
    P1(:,s) = P;Err_P(s,i) = max(abs(P-P(1)));
    M1(:,s) = M;Err_M(s,i) = max(abs(M-M(1)));
    E1(:,s) = E;Err_E(s,i) = max(abs(E-E(1)));
    H1(:,s) = H;Err_H(s,i) = max(abs(H-H(1)));
end
%% 
Scheme = ["IEQ_RK1";"IEQ_RK2";"IEQ_RK3";"IEQ_RK4";"SAV_RK3";"SAV_CN"];
Table = table(Scheme,Err_P,Err_M,Err_E,Err_H,CPU_time)
save("Table.mat","Table")
%% 
fig = figure(7);
plot(t+t(end),abs(H1-H1(1,:)),"--","LineWidth",2);
xlabel("$t_k$","Interpreter","latex","FontSize",20)
% ylabel("$|H_h^k-H_h^0|$","Interpreter","latex","FontSize",20)
title(" $|H_h^k-H_h^0|$ ","Interpreter","latex","FontSize",20)
legend("IEQ-RK1","IEQ-RK2","IEQ-RK3","IEQ-RK4","SAV-RK3","SAV-CN","Interpreter","latex","Location","best")
set(gca,'LineWidth',1,'YScale','log','FontSize',15,'FontName',"Times New Roman")
grid on
savefig(fig,"fig1_7.fig")
saveas(fig,"fig1_7.eps","epsc")
fig = figure(8);
plot(t+t(end),abs(E1-E1(1,:)),"--","LineWidth",2);
xlabel("$t_k$","Interpreter","latex","FontSize",20)
% ylabel("$$|E_h^k-H_h^0|$$","Interpreter","latex","FontSize",20)
title(" $|E_h^k-H_h^0|$ ","Interpreter","latex","FontSize",20)
legend("IEQ-RK1","IEQ-RK2","IEQ-RK3","IEQ-RK4","SAV-RK3","SAV-CN","Interpreter","latex","Location","best")
set(gca,'LineWidth',1,'YScale','log','FontSize',15,'FontName',"Times New Roman")
grid on
savefig(fig,"fig1_8.fig")
saveas(fig,"fig1_8.eps","epsc")
fig = figure(9);
plot(t+t(end),abs(P1-P1(1,:)),"--","LineWidth",2);
xlabel("$t_k$","Interpreter","latex","FontSize",20)
% ylabel("$E_{M_1}^k$","Interpreter","latex","FontSize",20)
title(" $|M_{1,h}^k-M_{1,h}^0|$ ","Interpreter","latex","FontSize",20)
legend("IEQ-RK1","IEQ-RK2","IEQ-RK3","IEQ-RK4","SAV-RK3","SAV-CN","Interpreter","latex","Location","best")
set(gca,'LineWidth',1,'YScale','log','FontSize',15,'FontName',"Times New Roman")
grid on
savefig(fig,"fig1_9.fig")
saveas(fig,"fig1_9.eps","epsc")
fig = figure(10);
plot(t+t(end),abs(M1-M1(1,:)),"--","LineWidth",2);
xlabel("$t_k$","Interpreter","latex","FontSize",20)
% ylabel("$E_{M_2}^k$","Interpreter","latex","FontSize",20)
set(gca,'YScale','log') 
title(" $|M_{2,h}^k-M_{2,h}^0|$ ","Interpreter","latex","FontSize",20)
legend("IEQ-RK1","IEQ-RK2","IEQ-RK3","IEQ-RK4","SAV-RK3","SAV-CN","Interpreter","latex","Location","best")
set(gca,'LineWidth',1,'YScale','log','FontSize',15,'FontName',"Times New Roman")
grid on
savefig(fig,"fig1_10.fig")
saveas(fig,"fig1_10.eps","epsc")



