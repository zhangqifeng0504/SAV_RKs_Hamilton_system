clear;clc
format short e
m = 1e3;L = 200;T = 1;
n = (16:4:36)';
n = 10*8.^(0:3)';
q = 1;pic = 0;
for s = 2
for i = 1:length(n)
    tic
    [u,Err,E,M,P,x,t,flag] = SAV_RK_Newton(m,n(i),s,q,pic);
    MaxErr(i,s) = max(max(Err));
    CPU_time(i,s) = toc;
    % subplot(4,length(n),i+4*(s-1))
    % plot(t(2:end)-t(1),flag,"g.","LineWidth",1,"MarkerSize",10)
    % ylabel("Iterations")
    % xlabel("$t_k$","Interpreter","latex")
    % title(strcat("$s = $",num2str(s),"$,\;n = $",num2str(n(i))),"Interpreter","latex")
    % set(gca,'LineWidth',1,'FontName',"Times New Roman","FontSize",15)
    % % set(gca,'xticklabel',[])
    % flag_max(i,s) = max(flag);
end
Ord(:,s) = [0;log2(MaxErr(1:end-1,s)./MaxErr(2:end,s))./(log2(n(2:end)./n(1:end-1)))];
end
table(MaxErr,Ord,CPU_time,flag_max)