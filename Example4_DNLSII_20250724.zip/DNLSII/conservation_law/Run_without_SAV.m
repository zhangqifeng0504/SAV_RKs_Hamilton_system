clear;clc
format short e
m = 1e4;n = 1e4;
q = 3;pic = 0;
for s = 1:4
    for i = 1:length(n)
        tic
        [u,Err,M,P,H,x,t] = SAV_RK_Newton2(m,n,s,q,pic);
        Max(s,i) = max(max(Err));
        CPU_time(s,i) = toc;
        P1(:,s) = P;Err_P(s,i) = max(abs(P-P(1)));
        M1(:,s) = M;Err_M(s,i) = max(abs(M-M(1)));
        % E1(:,s) = E;Err_E(s,i) = max(abs(E-E(1)));
        H1(:,s) = H;Err_H(s,i) = max(abs(H-H(1)));
    end
end
%% 
Scheme = ["SAV_RK1";"SAV_RK2";"SAV_RK3";"SAV_RK4"];
% Table = table(Scheme,Err_P,Err_M,Err_E,Err_H,CPU_time)
% save("Table.mat","Table")
% save data.mat
%% 
% fig = figure(1);
% imagesc(x,t+t(end),abs(u)')
% xlabel("$x$","Interpreter","latex","FontSize",20)
% ylabel("$t$","Interpreter","latex","FontSize",20)
% title(" $|u(x,t)|$ ","Interpreter","latex","FontSize",20)
% % legend("$M_{1,h}^k$","$M_{2,h}$","$H_h^k$","Interpreter","latex","Location","best")
% set(gca,'LineWidth',1,'FontSize',15,'FontName',"Times New Roman")
% colorbar;colormap jet
% savefig(fig,"fig4_1.fig")
% saveas(fig,"fig4_1.eps","epsc")
% fig = figure(2);
% [X,T] = meshgrid(x,t+t(end));
% mesh(X(1:10:end,1:10:end),T(1:10:end,1:10:end),abs(u(1:10:end,1:10:end)'))
% xlabel("$x$","Interpreter","latex","FontSize",20)
% ylabel("$t$","Interpreter","latex","FontSize",20)
% zlabel("$|u|$","Interpreter","latex","FontSize",20)
% set(gca,'LineWidth',1,'FontSize',15,'FontName',"Times New Roman")
% colorbar;colormap jet
% grid on
% savefig(fig,"fig4_2.fig")
% saveas(fig,"fig4_2.eps","epsc")
%% 
fig = figure(3);
plot(t+t(end),abs(H1-H1(1,:)),"--","LineWidth",2)
xlabel("$t_k$","Interpreter","latex","FontSize",20)
% ylabel("$Err_{E}^k$","Interpreter","latex","FontSize",20)
title("$|H_{h}^k-H_h^0|$ ","Interpreter","latex","FontSize",20)
legend("$s = 1$","$s = 2$","$s = 3$","$s = 4$","Interpreter","latex","Location","best")
set(gca,'LineWidth',1,'YScale','log','FontSize',15,'FontName',"Times New Roman")
grid on
savefig(fig,"fig4_3_2.fig")
saveas(fig,"fig4_3_2.eps","epsc")
% fig = figure(4);
% plot(t+t(end),abs(E1-E1(1,:)),"--","LineWidth",2)
% xlabel("$t_k$","Interpreter","latex","FontSize",20)
% % ylabel("$Err_{E}^k$","Interpreter","latex","FontSize",20)
% title("$|E_{h}^k-H_h^0|$ ","Interpreter","latex","FontSize",20)
% legend("$s = 1$","$s = 2$","$s = 3$","$s = 4$","Interpreter","latex","Location","best")
% set(gca,'LineWidth',1,'YScale','log','FontSize',15,'FontName',"Times New Roman")
% grid on
% savefig(fig,"fig4_4_2.fig")
% saveas(fig,"fig4_4_2.eps","epsc")
fig = figure(5);
plot(t+t(end),abs(P1-P1(1,:)),"--","LineWidth",2)
xlabel("$t_k$","Interpreter","latex","FontSize",20)
% ylabel("$Err_{M_1}^k$","Interpreter","latex","FontSize",20)
title(" $$|M_{2,h}^k-M_{2,h}^0|~{\rm with}~\mathbf{B} = -\mathrm{i}\mathbf{D}_1$$ ","Interpreter","latex","FontSize",20)
legend("$s = 1$","$s = 2$","$s = 3$","$s = 4$","Interpreter","latex","Location","best")
set(gca,'LineWidth',1,'YScale','log','FontSize',15,'FontName',"Times New Roman")
grid on
savefig(fig,"fig4_5_2.fig")
saveas(fig,"fig4_5_2.eps","epsc")
fig = figure(6);
plot(t+t(end),abs(M1-M1(1,:)),"--","LineWidth",2)
xlabel("$t_k$","Interpreter","latex","FontSize",20)
% ylabel("$Err_{M_2}^k$","Interpreter","latex","FontSize",20)
set(gca,'YScale','log') 
title("$|M_{2,h}^k-M_{2,h}^0|~{\rm with}~\mathbf{B} = \mathbf{I}_m$ ","Interpreter","latex","FontSize",20)
legend("$s = 1$","$s = 2$","$s = 3$","$s = 4$","Interpreter","latex","Location","best")
set(gca,'LineWidth',1,'YScale','log','FontSize',15,'FontName',"Times New Roman")
grid on
savefig(fig,"fig4_6_2.fig")
saveas(fig,"fig4_6_2.eps","epsc")
% %%
% k = 10;
% for i = 1:9
%     fig = figure(k+i);
%     row = 1+(1250*(i-1));
%     if i == 1
%         plot(x(1:m),abs(u(1:m,row)),"r-","LineWidth",2)
%         legend("$t_k = 0$","Interpreter","latex");
%     else
%         plot(x(1:m),abs(u(1:m,1)),"g-.",x(1:m),abs(u(1:m,row)),"r-","LineWidth",2)
%         legend("$t_k = 0$",strcat("$t_k = ",num2str(0+25*(i-1)),"$"),"Interpreter","latex");
%     end
%     grid on
%     ylim([0,2.5])
%     xlabel("$x$","Interpreter","latex","FontSize",20)
% %     ylabel("$Err_{M_2}^k$","Interpreter","latex","FontSize",20)
%     title(" $|u(x,t_k)|$ ","Interpreter","latex","FontSize",20)
%     set(gca,'LineWidth',2,'FontSize',15,'FontName',"Times New Roman")
%     savefig(fig,strcat("fig4_",num2str(k+i),".fig"))
%     saveas(fig,strcat("fig4_",num2str(k+i),".eps"),"epsc")
% 
% %     saveas(fig,strcat("fig1.",num2str(k+i)),"epsc")
% end


