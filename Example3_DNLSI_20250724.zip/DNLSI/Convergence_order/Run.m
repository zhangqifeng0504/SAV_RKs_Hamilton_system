clear;clc
format short e
m = 1e3;
n = (25:5:50)';
n = 10.^(1:4)';
q = 4;pic = 0;
for s = 1:4
for i = 1:length(n)
    tic
    [u,Err,E,M,P,H,x,t,flag] = SAV_RK_Newton(m,n(i),s,q,pic);
    subplot(4,length(n),i+4*(s-1))
    boxchart(flag,"LineWidth",2,"BoxFaceColor","g","MarkerStyle",".","MarkerColor","r","MarkerSize",20)
    ylabel("Iterations")
    xlabel(strcat("$\tau = $",num2str(1/n(i))),"Interpreter","latex")
    title(strcat("$s = $",num2str(s)),"Interpreter","latex")
    set(gca,'LineWidth',2,'FontName',"Times New Roman","FontSize",15)
    set(gca,'xticklabel',[])
    MaxErr(i,s) = max(max(Err));
    CPU_time(i,s) = toc;
end
Ord(:,s) = [0;log2(MaxErr(1:end-1,s)./MaxErr(2:end,s))./(log2(n(2:end)./n(1:end-1)))];
end
Table = table(MaxErr,Ord,CPU_time)
save("Table.mat","Table")