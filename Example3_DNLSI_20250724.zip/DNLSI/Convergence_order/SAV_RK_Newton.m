function [u,Err,E,M,P,H,x,t,flag] = SAV_RK_Newton(m,n,s,q,pic)
%UNTITLED3 此处提供此函数的摘要
%   此处提供详细说明
    bar = waitbar(0,'please wait...');
    %% 网格划分
    xa = -100;xb = 100;L = abs(xb-xa);hx = L/m;x = xa:hx:xb;x = x';
    % ta = -1;tb = 1;ht = abs(tb-ta)/n;t = ta:ht:tb;
    ta = -0.5;tb = 0.5;ht = abs(tb-ta)/n;t = ta:ht:tb;
    [X,T] = meshgrid(x,t);
    %% 真解和初边值条件
    if q == 1
        z =  @(x,t)-exp(t.*(1.0e-1+9.975e-1i)+x.*(-1.0+5.0e-2i)+1.0).*...
            (exp(t./5.0-x.*2.0+2.0).*(6.25e-3-1.25e-1i)-1.0).*1.0./...
            (exp(t./5.0-x.*2.0+2.0).*(6.25e-3+1.25e-1i)-1.0).^2;
    elseif q == 2
        z = @(x,t) -(exp(t.*(-2.0e-1+9.9e-1i)+x.*(1.0+1.0e-1i)+1.0)+ ...
            exp(t.*(2.0e-1+9.9e-1i)+x.*(1.0-1.0e-1i)+1.0)+ ...
            exp(t.*1.98i+x.*2.0+2.0).*(exp(t.*(-2.0e-1-9.9e-1i)+ ...
            x.*(1.0-1.0e-1i)+1.0).*(6.188118811881188e-2+6.188118811881188e-3i)+ ...
            exp(t.*(2.0e-1-9.9e-1i)+x.*(1.0+1.0e-1i)+1.0).*(6.188118811881188e-2- ...
            6.188118811881188e-3i)).*2.0e-2i).*1.0./(exp(t.*(-2.0./5.0)+x.*2.0+2.0).* ...
            (1.25e-2-1.25e-1i)+exp(t.*(2.0./5.0)+x.*2.0+2.0).*(-1.25e-2-1.25e-1i)+ ...
            exp(x.*4.0+4.0).*1.547029702970297e-6+exp(x.*(2.0-2.0e-1i)+2.0).* ...
            (1.237623762376238e-2-1.237623762376238e-1i)+exp(x.*(2.0+2.0e-1i)+2.0).* ...
            (-1.237623762376238e-2-1.237623762376238e-1i)-1.0).^2.*(exp(t.*(-2.0./5.0)+ ...
            x.*2.0+2.0).*(1.25e-2+1.25e-1i)+exp(t.*(2.0./5.0)+x.*2.0+2.0).*(-1.25e-2+ ...
            1.25e-1i)+exp(x.*4.0+4.0).*1.547029702970297e-6+exp(x.*(2.0-2.0e-1i)+2.0).* ...
            (-1.237623762376238e-2+1.237623762376238e-1i)+exp(x.*(2.0+2.0e-1i)+2.0).* ...
            (1.237623762376238e-2+1.237623762376238e-1i)-1.0);
    elseif q == 3
        z = @(x,t) -exp(t.*(4.0e-1+9.6e-1i)+x.*(-1.0+2.0e-1i)-1.0).*(exp(t.*(4.0./5.0)- ...
            x.*2.0-2.0).*(2.5e-2-1.25e-1i)-1.0).*1.0./(exp(t.*(4.0./5.0)-x.*2.0-2.0).*(2.5e-2+1.25e-1i)-1.0).^2;
    elseif q == 4
        z = @(x,t)-(exp(t.*(-2.0e-1+9.9e-1i)+x.*(1.0+1.0e-1i)+1.0)+exp(t.*(-5.0e-2+2.475e-1i)+x.*(5.0e-1+5.0e-2i)+1.0)+exp(t.*(-2.5e-1+1.2375i)+x.*(1.5+1.5e-1i)+2.0).*(exp(t.*(-2.0e-1-9.9e-1i)+x.*(1.0-1.0e-1i)+1.0).*(1.114805229360397e-1-3.683168658328827e-3i)+exp(t.*(-5.0e-2-2.475e-1i)+x.*(5.0e-1-5.0e-2i)+1.0).*(2.200046563135547e-1-3.693023290190576e-2i)).*(2.5e-2-1.2375e-1i)).*1.0./(exp(t.*(-1.0./1.0e+1)+x+2.0).*(2.5e-2-2.5e-1i)+exp(t.*(-1.0./2.0)+x.*3.0+4.0).*(3.887571430683135e-4+7.853679657945727e-5i)+exp(t.*(-2.0./5.0)+x.*2.0+2.0).*(1.25e-2-1.25e-1i)+exp(t.*(-2.5e-1-7.425e-1i)+x.*(1.5-5.0e-2i)+2.0).*(1.846511645095288e-2-1.100023281567774e-1i)+exp(t.*(-2.5e-1+7.425e-1i)+x.*(1.5+5.0e-2i)+2.0).*(7.366337316657652e-3-2.229610458720795e-1i)-1.0).^2.*(exp(t.*(-1.0./1.0e+1)+x+2.0).*(2.5e-2+2.5e-1i)+exp(t.*(-1.0./2.0)+x.*3.0+4.0).*(3.887571430683135e-4-7.853679657945727e-5i)+exp(t.*(-2.0./5.0)+x.*2.0+2.0).*(1.25e-2+1.25e-1i)+exp(t.*(-2.5e-1-7.425e-1i)+x.*(1.5-5.0e-2i)+2.0).*(7.366337316657652e-3+2.229610458720795e-1i)+exp(t.*(-2.5e-1+7.425e-1i)+x.*(1.5+5.0e-2i)+2.0).*(1.846511645095288e-2+1.100023281567774e-1i)-1.0);
    elseif q == 5
        z = @(x,t) -(exp(t.*(-5.0e-2+2.475e-1i)+x.*(5.0e-1+5.0e-2i)+1.0)+exp(t.*(-1.0e-1+9.975e-1i)+x.*(1.0+5.0e-2i)+1.0)-exp(t.*(-1.5e-1+1.245i)+x.*(1.5+1.0e-1i)+2.0).*(exp(t.*(-5.0e-2-2.475e-1i)+x.*(5.0e-1-5.0e-2i)+1.0).*(2.222222222222222e-1-2.222222222222222e-2i)+exp(t.*(-1.0e-1-9.975e-1i)+x.*(1.0-5.0e-2i)+1.0).*(1.111111111111111e-1-5.555555555555556e-3i)).*1.25e-1i).*1.0./(exp(t.*(-1.0./1.0e+1)+x+2.0).*(2.5e-2-2.5e-1i)+exp(t.*(-1.0./5.0)+x.*2.0+2.0).*(6.25e-3-1.25e-1i)+exp(t.*(-3.0./1.0e+1)+x.*3.0+4.0).*(3.838734567901235e-4+5.787037037037037e-5i)+exp(t.*(-1.5e-1-7.5e-1i)+x.*(3.0./2.0)+2.0).*(1.111111111111111e-2-1.111111111111111e-1i)+exp(t.*(-1.5e-1+7.5e-1i)+x.*(3.0./2.0)+2.0).*(1.111111111111111e-2-2.222222222222222e-1i)-1.0).^2.*(exp(t.*(-1.0./1.0e+1)+x+2.0).*(2.5e-2+2.5e-1i)+exp(t.*(-1.0./5.0)+x.*2.0+2.0).*(6.25e-3+1.25e-1i)+exp(t.*(-3.0./1.0e+1)+x.*3.0+4.0).*(3.838734567901235e-4-5.787037037037037e-5i)+exp(t.*(-1.5e-1-7.5e-1i)+x.*(3.0./2.0)+2.0).*(1.111111111111111e-2+2.222222222222222e-1i)+exp(t.*(-1.5e-1+7.5e-1i)+x.*(3.0./2.0)+2.0).*(1.111111111111111e-2+1.111111111111111e-1i)-1.0);
    elseif q == 6
        z = @(x,t) -(exp(t.*(-8.0e-3+8.4e-3i)+x.*(1.0e-1+4.0e-2i)+1.0)+exp(t.*(-4.0e-2+2.484e-1i)+x.*(5.0e-1+4.0e-2i)+1.0)-exp(t.*(-4.8e-2+2.568e-1i)+x.*(6.0e-1+8.0e-2i)+2.0).*(exp(t.*(-8.0e-3-8.4e-3i)+x.*(1.0e-1-4.0e-2i)+1.0).*(6.944444444444444-2.777777777777778i)+exp(t.*(-4.0e-2-2.484e-1i)+x.*(5.0e-1-4.0e-2i)+1.0).*(1.388888888888889-1.111111111111111e-1i)).*8.0e-2i).*1.0./(exp(t.*(-2.0./2.5e+1)+x+2.0).*(2.0e-2-2.5e-1i)+exp(t.*(-2.0./1.25e+2)+x./5.0+2.0).*(5.0e-1-1.25i)+exp(t.*(-1.2e+1./1.25e+2)+x.*(6.0./5.0)+4.0).*(5.975308641975309e-2+2.962962962962963e-2i)+exp(t.*(-4.8e-2-2.4e-1i)+x.*(3.0./5.0)+2.0).*(5.555555555555556e-2-1.388888888888889e-1i)+exp(t.*(-4.8e-2+2.4e-1i)+x.*(3.0./5.0)+2.0).*(5.555555555555556e-2-6.944444444444444e-1i)-1.0).^2.*(exp(t.*(-2.0./2.5e+1)+x+2.0).*(2.0e-2+2.5e-1i)+exp(t.*(-2.0./1.25e+2)+x./5.0+2.0).*(5.0e-1+1.25i)+exp(t.*(-1.2e+1./1.25e+2)+x.*(6.0./5.0)+4.0).*(5.975308641975309e-2-2.962962962962963e-2i)+exp(t.*(-4.8e-2-2.4e-1i)+x.*(3.0./5.0)+2.0).*(5.555555555555556e-2+6.944444444444444e-1i)+exp(t.*(-4.8e-2+2.4e-1i)+x.*(3.0./5.0)+2.0).*(5.555555555555556e-2+1.388888888888889e-1i)-1.0);
    end
    u = (zeros(m+1,n+1));Err = u;
    u(:,1) = z(x,t(1));%u(1,:) = z(x(1),t);u(m+1,:) = z(x(m+1),t);
%% 时间方向
    %% 高斯配置-隐式龙格库塔方法
    if s == 1
        A = 1/2;
        b = 1;
    elseif s == 2
        A = [1/4 1/4-sqrt(3)/6;1/4+sqrt(3)/6 1/4];
        b = [1/2 1/2];
    elseif s == 3
        A = [5/36 2/9-sqrt(15)/15 5/36-sqrt(15)/30;
            5/36+sqrt(15)/24 2/9 5/36-sqrt(15)/24;
            5/36+sqrt(15)/30 2/9+sqrt(15)/15 5/36];
        b = [5/18 4/9 5/18];
    elseif s == 4
        A = double([sqrt(sym(30))/144 + sym(1/8), sqrt(sym(30))/144 - (sqrt(sym(42))*sqrt(15 - 2*sqrt(sym(30))))/168 - (sqrt(sym(35))*sqrt(15 - 2*sqrt(sym(30))))/105 + sym(1/8), (23*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(6*sqrt(sym(30)) + 45)/42 - sqrt(sym(30))/144 + sqrt(70*sqrt(sym(30)) + 525)/1470 + (5*sqrt(84*sqrt(sym(30)) + 630))/2352 + sym(1/8), (23*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(6*sqrt(sym(30)) + 45)/42 - sqrt(sym(30))/144 - sqrt(70*sqrt(sym(30)) + 525)/1470 - (5*sqrt(84*sqrt(sym(30)) + 630))/2352 + sym(1/8); (sqrt(sym(35))*sqrt(15 - 2*sqrt(sym(30))))/105 + (sqrt(sym(42))*sqrt(15 - 2*sqrt(sym(30))))/168 + sqrt(sym(30))/144 + sym(1/8), sqrt(sym(30))/144 + sym(1/8), sqrt(6*sqrt(sym(30)) + 45)/42 - sqrt(sym(30))/144 - (23*sqrt(20*sqrt(sym(30)) + 150))/1680 + sqrt(70*sqrt(sym(30)) + 525)/1470 + (5*sqrt(84*sqrt(sym(30)) + 630))/2352 + sym(1/8), sqrt(6*sqrt(sym(30)) + 45)/42 - sqrt(sym(30))/144 - (23*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(70*sqrt(sym(30)) + 525)/1470 - (5*sqrt(84*sqrt(sym(30)) + 630))/2352 + sym(1/8); sqrt(sym(30))/144 + sqrt(6*sqrt(sym(30)) + 45)/84 - (13*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(70*sqrt(sym(30)) + 525)/420 - sqrt(84*sqrt(sym(30)) + 630)/336 + sym(1/8), sqrt(sym(30))/144 - sqrt(6*sqrt(sym(30)) + 45)/84 + (13*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(70*sqrt(sym(30)) + 525)/420 - sqrt(84*sqrt(sym(30)) + 630)/336 + sym(1/8), sym(1/8) - sqrt(sym(30))/144, (sqrt(sym(42))*sqrt(2*sqrt(sym(30)) + 15))/168 - (sqrt(sym(35))*sqrt(2*sqrt(sym(30)) + 15))/105 - sqrt(sym(30))/144 + sym(1/8); sqrt(sym(30))/144 + sqrt(6*sqrt(sym(30)) + 45)/84 - (13*sqrt(20*sqrt(sym(30)) + 150))/1680 + sqrt(70*sqrt(sym(30)) + 525)/420 + sqrt(84*sqrt(sym(30)) + 630)/336 + sym(1/8), sqrt(sym(30))/144 - sqrt(6*sqrt(sym(30)) + 45)/84 + (13*sqrt(20*sqrt(sym(30)) + 150))/1680 + sqrt(70*sqrt(sym(30)) + 525)/420 + sqrt(84*sqrt(sym(30)) + 630)/336 + sym(1/8), (sqrt(sym(35))*sqrt(2*sqrt(sym(30)) + 15))/105 - (sqrt(sym(42))*sqrt(2*sqrt(sym(30)) + 15))/168 - sqrt(sym(30))/144 + sym(1/8), sym(1/8) - sqrt(sym(30))/144]);
        b = double([sqrt(sym(30))/72 + sym(1/4), sqrt(sym(30))/72 + sym(1/4), sym(1/4) - sqrt(sym(30))/72, sym(1/4) - sqrt(sym(30))/72]);
    elseif s == 5
        A = double([sym(32/225), (13*sqrt(sym(70)))/3600 + (11*sqrt(245 - 14*sqrt(sym(70))))/1440 + (23*sqrt(350 - 20*sqrt(sym(70))))/5760 + sym(161/1800), (13*sqrt(sym(70)))/3600 - (11*sqrt(245 - 14*sqrt(sym(70))))/1440 - (23*sqrt(350 - 20*sqrt(sym(70))))/5760 + sym(161/1800), (11*sqrt(14*sqrt(sym(70)) + 245))/1440 - (13*sqrt(sym(70)))/3600 - (23*sqrt(20*sqrt(sym(70)) + 350))/5760 + sym(161/1800), (23*sqrt(20*sqrt(sym(70)) + 350))/5760 - (11*sqrt(14*sqrt(sym(70)) + 245))/1440 - (13*sqrt(sym(70)))/3600 + sym(161/1800); sym(32/225) - (4*sqrt(350 - 20*sqrt(sym(70))))/1215 - (92*sqrt(245 - 14*sqrt(sym(70))))/8505, (13*sqrt(sym(70)))/3600 + sym(161/1800), (13*sqrt(sym(70)))/3600 - (2*sqrt(245 - 14*sqrt(sym(70))))/315 - sqrt(350 - 20*sqrt(sym(70)))/360 + sym(161/1800), (4*sqrt(14*sqrt(sym(70)) + 245))/2835 - (13*sqrt(sym(70)))/3600 + (11*sqrt(20*sqrt(sym(70)) + 350))/6480 - (43*sqrt(30*sqrt(sym(70)) + 525))/10935 + (2969*sqrt(84*sqrt(sym(70)) + 1470))/1224720 + sym(161/1800), (2969*sqrt(84*sqrt(sym(70)) + 1470))/1224720 - (4*sqrt(14*sqrt(sym(70)) + 245))/2835 - (11*sqrt(20*sqrt(sym(70)) + 350))/6480 - (43*sqrt(30*sqrt(sym(70)) + 525))/10935 - (13*sqrt(sym(70)))/3600 + sym(161/1800); (92*sqrt(245 - 14*sqrt(sym(70))))/8505 + (4*sqrt(350 - 20*sqrt(sym(70))))/1215 + sym(32/225), (13*sqrt(sym(70)))/3600 + (2*sqrt(245 - 14*sqrt(sym(70))))/315 + sqrt(350 - 20*sqrt(sym(70)))/360 + sym(161/1800), (13*sqrt(sym(70)))/3600 + sym(161/1800), (4*sqrt(14*sqrt(sym(70)) + 245))/2835 - (13*sqrt(sym(70)))/3600 + (11*sqrt(20*sqrt(sym(70)) + 350))/6480 + (43*sqrt(30*sqrt(sym(70)) + 525))/10935 - (2969*sqrt(84*sqrt(sym(70)) + 1470))/1224720 + sym(161/1800), (43*sqrt(30*sqrt(sym(70)) + 525))/10935 - (4*sqrt(14*sqrt(sym(70)) + 245))/2835 - (11*sqrt(20*sqrt(sym(70)) + 350))/6480 - (13*sqrt(sym(70)))/3600 - (2969*sqrt(84*sqrt(sym(70)) + 1470))/1224720 + sym(161/1800); (4*sqrt(20*sqrt(sym(70)) + 350))/1215 - (92*sqrt(14*sqrt(sym(70)) + 245))/8505 + sym(32/225), (13*sqrt(sym(70)))/3600 - (113*sqrt(14*sqrt(sym(70)) + 245))/34020 - (59*sqrt(20*sqrt(sym(70)) + 350))/19440 + sqrt(30*sqrt(sym(70)) + 525)/540 - (19*sqrt(84*sqrt(sym(70)) + 1470))/15120 + sym(161/1800), (13*sqrt(sym(70)))/3600 - (113*sqrt(14*sqrt(sym(70)) + 245))/34020 - (59*sqrt(20*sqrt(sym(70)) + 350))/19440 - sqrt(30*sqrt(sym(70)) + 525)/540 + (19*sqrt(84*sqrt(sym(70)) + 1470))/15120 + sym(161/1800), sym(161/1800) - (13*sqrt(sym(70)))/3600, sqrt(20*sqrt(sym(70)) + 350)/360 - (2*sqrt(14*sqrt(sym(70)) + 245))/315 - (13*sqrt(sym(70)))/3600 + sym(161/1800); (92*sqrt(14*sqrt(sym(70)) + 245))/8505 - (4*sqrt(20*sqrt(sym(70)) + 350))/1215 + sym(32/225), (13*sqrt(sym(70)))/3600 + (113*sqrt(14*sqrt(sym(70)) + 245))/34020 + (59*sqrt(20*sqrt(sym(70)) + 350))/19440 + sqrt(30*sqrt(sym(70)) + 525)/540 - (19*sqrt(84*sqrt(sym(70)) + 1470))/15120 + sym(161/1800), (13*sqrt(sym(70)))/3600 + (113*sqrt(14*sqrt(sym(70)) + 245))/34020 + (59*sqrt(20*sqrt(sym(70)) + 350))/19440 - sqrt(30*sqrt(sym(70)) + 525)/540 + (19*sqrt(84*sqrt(sym(70)) + 1470))/15120 + sym(161/1800), (2*sqrt(14*sqrt(sym(70)) + 245))/315 - (13*sqrt(sym(70)))/3600 - sqrt(20*sqrt(sym(70)) + 350)/360 + sym(161/1800), sym(161/1800) - (13*sqrt(sym(70)))/3600]);
        b = double([sym(64/225), (13*sqrt(sym(70)))/1800 + sym(161/900), (13*sqrt(sym(70)))/1800 + sym(161/900), sym(161/900) - (13*sqrt(sym(70)))/1800, sym(161/900) - (13*sqrt(sym(70)))/1800]);
    elseif s == 6
        A = [1/4 0;1/2 1/4];
        b = [1/2 1/2];s = length(b);
    end
    %%  空间方向  
    % 谱微分矩阵对应向量
    [Lam1,Lam2] = DS(m,L);Lam0 = 1i*ht*Lam2;
    %% 循环求解过程所用矩阵系数
    J = matlabFunction(reshape((eye(s)-sym("x")*A)\eye(s),1,[]));
    F = reshape(J(Lam0),[],s);
    %% 初始守恒律
    M = zeros(1,n+1);P = M;E = M;V = M;H = E;
    D1u1 = dfft(u(1:m,1),Lam1);
    M(1) = dispord(u(1:m,1),u(1:m,1),hx);
    P(1) = dispord(u(1:m,1),1,hx);
    E(1) = real(1i*dispord(u(1:m,1),D1u1,hx))+1/2*dispord(u(1:m,1).^2,u(1:m,1).^2,hx);
    H(1) = E(1);
    V(1) = sqrt(M(1));
    ep = 1e-12;% 允许最大误差精度
    tic
    for k = 1:n
        str=['计算中...',num2str(100*(k-1)/n),'%','(',num2str((k-1)),'/',num2str(n),')',';','当前耗时',num2str(toc),'秒'];    % 百分比形式显示处理进程,不需要删掉这行代码就行
        waitbar((k-1)/n,bar,str)                       % 更新进度条bar，配合bar使用
        %% 初始值
        U0 = u(1:m,k);
        v0 = V(k);
        f0 = dfft(-1i*dfft(U0,Lam1)+abs(U0.^2).*U0,-Lam1);
        %% 主要迭代变量
        f = kron(ones(1,s),f0);g = zeros(s,1);
        flag(k) = 0;
        while 1
            flag(k) = flag(k)+1;
            U = reshape(kron(ones(s,1),U0)+ht*sum(kron(A,ones(m,1)).*kron(ones(s,1),f),2),[],s);
            D1U1 = dfft(U,Lam1);
            E_temp = real(1i*(dispord(U,D1U1,hx)))+1/2*dispord(U.^2,U.^2,hx);
            M_temp = dispord(U,U,hx);
            V_temp = sqrt(E(1)-E_temp+M_temp);
            Q = (-1i*D1U1+abs(U.^2).*U-U)./V_temp;
            g = -real(dispord(Q,f,hx));
            v = v0+ht*A*g'; 
            w = f-dfft(U+Q.*v',-Lam1);
            %% 矩阵求解
            err = -ifft(reshape(sum(F.*kron(ones(s,1),fft(w)),2),[],s));
            f = f+err;
            e1 = max(max(abs(err)));
            if abs(e1) <= ep
                break;
            end
        end
        u(1:m,k+1) = (U0+ht*sum(b.*f,2));D1u1 = dfft(u(1:m,1),Lam1);
        Err(1:m,k+1) = abs(u(1:m,k+1)-z(x(1:m),t(k+1)));
        V(k+1) = v0+ht*b*g';
        P(k+1) = hx*sum((u(1:m,k+1)));
        M(k+1) = hx*sum(abs(u(1:m,k+1).^2));
        E(k+1) = V(k+1)^2-M(k+1)+E(1);
        H(k+1) = real(1i*dispord(u(1:m,k+1),D1u1,hx))+1/2*dispord(u(1:m,k+1).^2,u(1:m,k+1).^2,hx);
    end
    close(bar)
    %% 验证质量，能量守恒
    if pic == 1
        figure(1)
        imagesc(x,t+t(end),abs(u'))
        xlabel("$x$","Interpreter","latex","FontSize",20)
        ylabel("$t$","Interpreter","latex","FontSize",20)
        title("$|u|$","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
        figure(2)
        plot(t+t(end),abs(M-M(1)),"--","LineWidth",2)
        xlabel("$t_k$","Interpreter","latex","FontSize",20)
        ylabel("$|M_{1,h}^k-M_{1,h}^0|$","Interpreter","latex","FontSize",20)
        set(gca,'YScale','log') 
        title(" Errors of $M_{1,h}^k$ ","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
%         legend('$h = \frac{1}{10},\,\tau = \frac{1}{100}$','Interpreter','latex',"Location","southeast")
        hold on
        figure(3)
        plot(t+t(end),abs(E-E(1)),"--","LineWidth",2)
        xlabel("$t_k$","Interpreter","latex","FontSize",20)
        ylabel("$|M_{3,h}^k-M_{3,h}^0|$","Interpreter","latex","FontSize",20)
        set(gca,'YScale','log') 
        title(" Errors of $M_{3,h}^k$ ","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
%         legend('$h = \frac{1}{10},\,\tau = \frac{1}{100}$','Interpreter','latex',"Location","southeast")
        hold on
        figure(4)
        plot(t+t(end),abs(P-P(1)),"--","LineWidth",2)
        xlabel("$t_k$","Interpreter","latex","FontSize",20)
        ylabel("$|M_{2,h}^k-M_{2,h}^0|$","Interpreter","latex","FontSize",20)
        set(gca,'YScale','log') 
        title(" Errors of $M_{2,h}^k$ ","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
%         legend('$h = \frac{1}{10},\,\tau = \frac{1}{100}$','Interpreter','latex',"Location","southeast")
        hold on
        figure(5)
        plot(t+t(end),M,"r-",t+t(end),P,"g-",t+t(end),E,"b-","LineWidth",2)
        xlabel("$t_k$","Interpreter","latex","FontSize",20)
        legend("M_{1,h}^k","M_{2,h}^k","M_{3,h}^k")
        figure(6)
        mesh(X(1:5:end,1:5:end),T(1:5:end,1:5:end),abs(u(1:5:end,1:5:end)'))
        xlabel("$x$","Interpreter","latex","FontSize",20)
        ylabel("$t$","Interpreter","latex","FontSize",20)
        zlabel("$|u|$","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
        legend("M_{1,h}^k","M_{2,h}^k","M_{3,h}^k")
        figure(7)
        plot(t+t(end),abs(H-H(1)),"--","LineWidth",2)
        xlabel("$t_k$","Interpreter","latex","FontSize",20)
        ylabel("$|H^k-H^0|$","Interpreter","latex","FontSize",20)
        set(gca,'YScale','log') 
        title(" Errors of $M_{3,h}^k$ ","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
    end
%%  附录函数
    %% dispord：离散内积函数
    function I = dispord(u,v,h)
        I = (h*sum(u.*conj(v),1));
    end
    %% DS: 谱微分矩阵
    function [Lam1,Lam2] = DS(m,L)
        lambda = 2*pi/L;
        r1 = (zeros(m,1));  
        r1(1:m/2) = 0:m/2-1; r1(m/2+2:m) = -m/2+1:-1;
        r2 = r1; r2(m/2+1) = m/2;
        Lam1 = (1i * lambda * r1);
        Lam2 = (1i * lambda * r2).^2;
    end
    %% fun: 基于快速傅里叶变换的微分矩阵
    function y = dfft(u,d)
        y = ifft(d.*fft(u)); 
    end
end