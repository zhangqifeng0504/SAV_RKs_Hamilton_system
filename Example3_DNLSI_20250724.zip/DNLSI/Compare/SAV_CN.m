function [u,Err,E,M,P,H,x,t] = SAV_CN(m,n,s,q,pic)
%UNTITLED3 此处提供此函数的摘要
%   此处提供详细说明
    bar = waitbar(0,'please wait...');
    %% 网格划分
    xa = -100;xb = 100;L = abs(xb-xa);hx = L/m;x = xa:hx:xb;x = x';
    ta =-25;tb = 25;ht = abs(tb-ta)/n;t = ta:ht:tb;
    [X,T] = meshgrid(t,x);
    %% 真解和初边值条件
    if q == 1
        z =  @(x,t)-exp(t.*(1.0e-1+9.975e-1i)+x.*(-1.0+5.0e-2i)+1.0).*...
            (exp(t./5.0-x.*2.0+2.0).*(6.25e-3-1.25e-1i)-1.0).*1.0./...
            (exp(t./5.0-x.*2.0+2.0).*(6.25e-3+1.25e-1i)-1.0).^2;
    elseif q == 2
        z = @(x,t) -(exp(t.*(-2.0e-1+9.9e-1i)+x.*(1.0+1.0e-1i)+1.0)+ ...
            exp(t.*(2.0e-1+9.9e-1i)+x.*(1.0-1.0e-1i)+1.0)+ ...
            exp(t.*1.98i+x.*2.0+2.0).*(exp(t.*(-2.0e-1-9.9e-1i)+ ...
            x.*(1.0-1.0e-1i)+1.0).*(6.188118811881188e-2+6.188118811881188e-3i)+ ...
            exp(t.*(2.0e-1-9.9e-1i)+x.*(1.0+1.0e-1i)+1.0).*(6.188118811881188e-2- ...
            6.188118811881188e-3i)).*2.0e-2i).*1.0./(exp(t.*(-2.0./5.0)+x.*2.0+2.0).* ...
            (1.25e-2-1.25e-1i)+exp(t.*(2.0./5.0)+x.*2.0+2.0).*(-1.25e-2-1.25e-1i)+ ...
            exp(x.*4.0+4.0).*1.547029702970297e-6+exp(x.*(2.0-2.0e-1i)+2.0).* ...
            (1.237623762376238e-2-1.237623762376238e-1i)+exp(x.*(2.0+2.0e-1i)+2.0).* ...
            (-1.237623762376238e-2-1.237623762376238e-1i)-1.0).^2.*(exp(t.*(-2.0./5.0)+ ...
            x.*2.0+2.0).*(1.25e-2+1.25e-1i)+exp(t.*(2.0./5.0)+x.*2.0+2.0).*(-1.25e-2+ ...
            1.25e-1i)+exp(x.*4.0+4.0).*1.547029702970297e-6+exp(x.*(2.0-2.0e-1i)+2.0).* ...
            (-1.237623762376238e-2+1.237623762376238e-1i)+exp(x.*(2.0+2.0e-1i)+2.0).* ...
            (1.237623762376238e-2+1.237623762376238e-1i)-1.0);
    elseif q == 3
        z = @(x,t) -exp(t.*(4.0e-1+9.6e-1i)+x.*(-1.0+2.0e-1i)-1.0).*(exp(t.*(4.0./5.0)- ...
            x.*2.0-2.0).*(2.5e-2-1.25e-1i)-1.0).*1.0./(exp(t.*(4.0./5.0)-x.*2.0-2.0).*(2.5e-2+1.25e-1i)-1.0).^2;
    elseif q == 4
        z = @(x,t)-(exp(t.*(-2.0e-1+9.9e-1i)+x.*(1.0+1.0e-1i)+1.0)+exp(t.*(-5.0e-2+2.475e-1i)+x.*(5.0e-1+5.0e-2i)+1.0)+exp(t.*(-2.5e-1+1.2375i)+x.*(1.5+1.5e-1i)+2.0).*(exp(t.*(-2.0e-1-9.9e-1i)+x.*(1.0-1.0e-1i)+1.0).*(1.114805229360397e-1-3.683168658328827e-3i)+exp(t.*(-5.0e-2-2.475e-1i)+x.*(5.0e-1-5.0e-2i)+1.0).*(2.200046563135547e-1-3.693023290190576e-2i)).*(2.5e-2-1.2375e-1i)).*1.0./(exp(t.*(-1.0./1.0e+1)+x+2.0).*(2.5e-2-2.5e-1i)+exp(t.*(-1.0./2.0)+x.*3.0+4.0).*(3.887571430683135e-4+7.853679657945727e-5i)+exp(t.*(-2.0./5.0)+x.*2.0+2.0).*(1.25e-2-1.25e-1i)+exp(t.*(-2.5e-1-7.425e-1i)+x.*(1.5-5.0e-2i)+2.0).*(1.846511645095288e-2-1.100023281567774e-1i)+exp(t.*(-2.5e-1+7.425e-1i)+x.*(1.5+5.0e-2i)+2.0).*(7.366337316657652e-3-2.229610458720795e-1i)-1.0).^2.*(exp(t.*(-1.0./1.0e+1)+x+2.0).*(2.5e-2+2.5e-1i)+exp(t.*(-1.0./2.0)+x.*3.0+4.0).*(3.887571430683135e-4-7.853679657945727e-5i)+exp(t.*(-2.0./5.0)+x.*2.0+2.0).*(1.25e-2+1.25e-1i)+exp(t.*(-2.5e-1-7.425e-1i)+x.*(1.5-5.0e-2i)+2.0).*(7.366337316657652e-3+2.229610458720795e-1i)+exp(t.*(-2.5e-1+7.425e-1i)+x.*(1.5+5.0e-2i)+2.0).*(1.846511645095288e-2+1.100023281567774e-1i)-1.0);
    elseif q == 5
        z = @(x,t) -(exp(t.*(-5.0e-2+2.475e-1i)+x.*(5.0e-1+5.0e-2i)+1.0)+exp(t.*(-1.0e-1+9.975e-1i)+x.*(1.0+5.0e-2i)+1.0)-exp(t.*(-1.5e-1+1.245i)+x.*(1.5+1.0e-1i)+2.0).*(exp(t.*(-5.0e-2-2.475e-1i)+x.*(5.0e-1-5.0e-2i)+1.0).*(2.222222222222222e-1-2.222222222222222e-2i)+exp(t.*(-1.0e-1-9.975e-1i)+x.*(1.0-5.0e-2i)+1.0).*(1.111111111111111e-1-5.555555555555556e-3i)).*1.25e-1i).*1.0./(exp(t.*(-1.0./1.0e+1)+x+2.0).*(2.5e-2-2.5e-1i)+exp(t.*(-1.0./5.0)+x.*2.0+2.0).*(6.25e-3-1.25e-1i)+exp(t.*(-3.0./1.0e+1)+x.*3.0+4.0).*(3.838734567901235e-4+5.787037037037037e-5i)+exp(t.*(-1.5e-1-7.5e-1i)+x.*(3.0./2.0)+2.0).*(1.111111111111111e-2-1.111111111111111e-1i)+exp(t.*(-1.5e-1+7.5e-1i)+x.*(3.0./2.0)+2.0).*(1.111111111111111e-2-2.222222222222222e-1i)-1.0).^2.*(exp(t.*(-1.0./1.0e+1)+x+2.0).*(2.5e-2+2.5e-1i)+exp(t.*(-1.0./5.0)+x.*2.0+2.0).*(6.25e-3+1.25e-1i)+exp(t.*(-3.0./1.0e+1)+x.*3.0+4.0).*(3.838734567901235e-4-5.787037037037037e-5i)+exp(t.*(-1.5e-1-7.5e-1i)+x.*(3.0./2.0)+2.0).*(1.111111111111111e-2+2.222222222222222e-1i)+exp(t.*(-1.5e-1+7.5e-1i)+x.*(3.0./2.0)+2.0).*(1.111111111111111e-2+1.111111111111111e-1i)-1.0);
    elseif q == 6
        z = @(x,t) -(exp(t.*(-8.0e-3+8.4e-3i)+x.*(1.0e-1+4.0e-2i)+1.0)+exp(t.*(-4.0e-2+2.484e-1i)+x.*(5.0e-1+4.0e-2i)+1.0)-exp(t.*(-4.8e-2+2.568e-1i)+x.*(6.0e-1+8.0e-2i)+2.0).*(exp(t.*(-8.0e-3-8.4e-3i)+x.*(1.0e-1-4.0e-2i)+1.0).*(6.944444444444444-2.777777777777778i)+exp(t.*(-4.0e-2-2.484e-1i)+x.*(5.0e-1-4.0e-2i)+1.0).*(1.388888888888889-1.111111111111111e-1i)).*8.0e-2i).*1.0./(exp(t.*(-2.0./2.5e+1)+x+2.0).*(2.0e-2-2.5e-1i)+exp(t.*(-2.0./1.25e+2)+x./5.0+2.0).*(5.0e-1-1.25i)+exp(t.*(-1.2e+1./1.25e+2)+x.*(6.0./5.0)+4.0).*(5.975308641975309e-2+2.962962962962963e-2i)+exp(t.*(-4.8e-2-2.4e-1i)+x.*(3.0./5.0)+2.0).*(5.555555555555556e-2-1.388888888888889e-1i)+exp(t.*(-4.8e-2+2.4e-1i)+x.*(3.0./5.0)+2.0).*(5.555555555555556e-2-6.944444444444444e-1i)-1.0).^2.*(exp(t.*(-2.0./2.5e+1)+x+2.0).*(2.0e-2+2.5e-1i)+exp(t.*(-2.0./1.25e+2)+x./5.0+2.0).*(5.0e-1+1.25i)+exp(t.*(-1.2e+1./1.25e+2)+x.*(6.0./5.0)+4.0).*(5.975308641975309e-2-2.962962962962963e-2i)+exp(t.*(-4.8e-2-2.4e-1i)+x.*(3.0./5.0)+2.0).*(5.555555555555556e-2+6.944444444444444e-1i)+exp(t.*(-4.8e-2+2.4e-1i)+x.*(3.0./5.0)+2.0).*(5.555555555555556e-2+1.388888888888889e-1i)-1.0);
    end
    u = zeros(m+1,n+1);Err = u;
    u(:,1) = z(x,t(1));u(1,:) = z(x(1),t);u(m+1,:) = z(x(m+1),t);
%%  空间方向  
    %% 谱微分矩阵对应向量
    [Lam1,Lam2] = DS(m,L);
    %% 初始守恒律
    M = zeros(1,n+1);P = M;E = M;V = E;H = E;
    D1u1 = dfft(u(1:m,1),Lam1);
    M(1) = hx*sum(abs(u(1:m,1).^2));
    P(1) = hx*sum((u(1:m,1)));
    E(1) = 2*imag(dispord(D1u1,u(1:m,1),hx))+dispord(u(1:m,1).^2,u(1:m,1).^2,hx);
    H(1) = E(1);
    V(1) = sqrt(dispord(u(1:m,1).^2,u(1:m,1).^2,hx));
    ep = 1e-12;% 允许最大误差精度
    tic
    for k = 1:n
        str=['计算中...',num2str(100*(k-1)/n),'%','(',num2str((k-1)),'/',num2str(n),')',';','当前耗时',num2str(toc),'秒'];    % 百分比形式显示处理进程,不需要删掉这行代码就行
        waitbar((k-1)/n,bar,str)                       % 更新进度条bar，配合bar使用
        %% 初始值
        U0 = u(1:m,k);
        while 1
            temp = U0;
            V_temp = sqrt(dispord(U0.^2,U0.^2,hx));
            Q = (( abs(U0.^2).*U0 ))./V_temp;
            v0 = V(k)+2*real(dispord(Q,U0-u(1:m,k),hx));
            b = 2/ht*u(1:m,k)-dfft(Q*v0,Lam1);
            U0 = dfft(b,1./(2/ht-1i*Lam2));
            err = max(abs(U0-temp));
            if err <= ep
                break;
            end
        end
        u(1:m,k+1) = 2*U0-u(1:m,k);Err(1:m,k+1) = abs(u(1:m,k+1)-z(x(1:m),t(k+1)));
        V(k+1) = 2*v0-V(k);
        E(k+1) = 2*imag(dispord(dfft(u(1:m,k+1),Lam1),u(1:m,k+1),hx))+V(k+1)^2;
        H(k+1) = 2*imag(dispord(dfft(u(1:m,k+1),Lam1),u(1:m,k+1),hx))+dispord(u(1:m,k+1).^2,u(1:m,k+1).^2,hx);
        P(k+1) = hx*sum(abs(u(1:m,k+1)));
        M(k+1) = hx*sum(abs(u(1:m,k+1).^2));
    end
    close(bar)
    %% 验证质量，能量守恒
    if pic == 1
        figure(1)
        imagesc(x,t+t(end),abs(u'))
        xlabel("$x$","Interpreter","latex","FontSize",20)
        ylabel("$t$","Interpreter","latex","FontSize",20)
        title("$|u|$","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
        figure(2)
        plot(t+t(end),abs(M-M(1)),"r--","LineWidth",2)
        xlabel("$t_k$","Interpreter","latex","FontSize",20)
        ylabel("$|M_{1,h}^k-M_{1,h}^0|$","Interpreter","latex","FontSize",20)
        set(gca,'YScale','log') 
        title(" Errors of $M_{1,h}^k$ ","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
%         legend('$h = \frac{1}{10},\,\tau = \frac{1}{100}$','Interpreter','latex',"Location","southeast")
        hold on
        figure(3)
        plot(t+t(end),abs(E-E(1)),"r--","LineWidth",2)
        xlabel("$t_k$","Interpreter","latex","FontSize",20)
        ylabel("$H_h^k-H_h^0|$","Interpreter","latex","FontSize",20)
        set(gca,'YScale','log') 
        title(" Errors of $H_h^k$ ","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
%         legend('$h = \frac{1}{10},\,\tau = \frac{1}{100}$','Interpreter','latex',"Location","southeast")
        hold on
        figure(4)
        plot(t+t(end),abs(P-P(1)),"r--","LineWidth",2)
        xlabel("$t_k$","Interpreter","latex","FontSize",20)
        ylabel("$|M_{2,h}^k-M_{2,h}^0|$","Interpreter","latex","FontSize",20)
        set(gca,'YScale','log') 
        title(" Errors of $M_{2,h}^k$ ","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
%         legend('$h = \frac{1}{10},\,\tau = \frac{1}{100}$','Interpreter','latex',"Location","southeast")
        hold on
        figure(5)
        plot(t+t(end),M,"r-",t+t(end),P,"g-",t+t(end),E,"b-","LineWidth",2)
        xlabel("$t_k$","Interpreter","latex","FontSize",20)
        legend("M_{1,h}^k","M_{2,h}^k","H_h^k")
        figure(6)
        mesh(X(1:5:end,1:5:end),T(1:5:end,1:5:end),abs(u(1:5:end,1:5:end)'))
        xlabel("$x$","Interpreter","latex","FontSize",20)
        ylabel("$t$","Interpreter","latex","FontSize",20)
        zlabel("$|u|$","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
        legend("M_{1,h}^k","M_{2,h}^k","H_h^k","Interpreter","latex","FontSize",20)
    end
%%  附录函数
    %% dispord：离散内积函数
    function I = dispord(u,v,h)
        I = (h*sum(u.*conj(v)));
    end
    %% DS: 谱微分矩阵
    function [Lam1,Lam2] = DS(m,L)
        lambda = 2*pi/L;
        r1 = (zeros(m,1));  
        r1(1:m/2) = 0:m/2-1; r1(m/2+2:m) = -m/2+1:-1;
        r2 = r1; r2(m/2+1) = m/2;
        Lam1 = (1i * lambda * r1);
        Lam2 = (1i * lambda * r2).^2;
    end
    %% fun: 基于快速傅里叶变换的微分矩阵
    function y = dfft(u,d)
        y = ifft(d.*fft(u)); 
    end
%     %% fun: 基于快速傅里叶变换的微分矩阵
%     function y = fun(u,v)
%         y = u; 
%     end
end