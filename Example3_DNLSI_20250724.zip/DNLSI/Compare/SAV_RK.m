function [u,Err,E,M,P,x,t] = SAV_RK(m,n,s,q,pic)
%   m:空间划分；n:时间划分;s:s-IRK;q:用来控制不同真解;pic:控制画图;
%   main函数内底部有内部调用函数的定义，主要有：
%   dispord：离散内积函数；
%   DS: 谱微分矩阵对应的中间列向量；
%   fun:  快速傅里叶变换，点乘上一个列向量，再逆变换。
    bar = waitbar(0,'please wait...');
    %% 网格划分
    xa = -100;xb = 100;L = abs(xb-xa);hx = L/m;x = xa:hx:xb;x = x';
    ta = -100;tb = 100;ht = abs(tb-ta)/n;t = ta:ht:tb;
    %% 真解和初边值条件
    if q == 0
        z = @(x,t) ((exp(t.*(1.8e-2+3.7975e-2i)+x.*(-2.0e-1+4.5e-2i)).*(2.522015791327477e+18+2.702159776422301e+17i)+exp(t.*(3.3e-2+8.6975e-2i)+x.*(3.0e-1-5.5e-2i)).*(-3.107483742885642e+18-2.702159776422294e+17i)+exp(t.*(1.8e-2-3.7975e-2i)+x.*(-2.0e-1-4.5e-2i)).*exp(t.*(1.8e-2+3.7975e-2i)+x.*(-2.0e-1+4.5e-2i)).*exp(t.*(3.3e-2+8.6975e-2i)+x.*(3.0e-1-5.5e-2i)).*(3.107483742885642e+18-2.702159776422294e+17i)+exp(t.*(1.8e-2+3.7975e-2i)+x.*(-2.0e-1+4.5e-2i)).*exp(t.*(3.3e-2-8.6975e-2i)+x.*(3.0e-1+5.5e-2i)).*exp(t.*(3.3e-2+8.6975e-2i)+x.*(3.0e-1-5.5e-2i)).*(-2.522015791327477e+18+2.702159776422301e+17i)).*-8.881784197001252e-17i)./(exp(t.*(1.8e-2-3.7975e-2i)+x.*(-2.0e-1-4.5e-2i)).*exp(t.*(1.8e-2+3.7975e-2i)+x.*(-2.0e-1+4.5e-2i)).*(-1.0-5.0e+1i)+exp(t.*(1.8e-2-3.7975e-2i)+x.*(-2.0e-1-4.5e-2i)).*exp(t.*(3.3e-2+8.6975e-2i)+x.*(3.0e-1-5.5e-2i)).*7.32e+2+exp(t.*(1.8e-2+3.7975e-2i)+x.*(-2.0e-1+4.5e-2i)).*exp(t.*(3.3e-2-8.6975e-2i)+x.*(3.0e-1+5.5e-2i)).*4.92e+2+exp(t.*(3.3e-2-8.6975e-2i)+x.*(3.0e-1+5.5e-2i)).*exp(t.*(3.3e-2+8.6975e-2i)+x.*(3.0e-1-5.5e-2i)).*(-1.0+5.0e+1i)+exp(t.*(1.8e-2-3.7975e-2i)+x.*(-2.0e-1-4.5e-2i)).*exp(t.*(1.8e-2+3.7975e-2i)+x.*(-2.0e-1+4.5e-2i)).*exp(t.*(3.3e-2-8.6975e-2i)+x.*(3.0e-1+5.5e-2i)).*exp(t.*(3.3e-2+8.6975e-2i)+x.*(3.0e-1-5.5e-2i)).*(6.37e+2-1.3e+2i)+6.37e+2+1.3e+2i);
    elseif q == 1
        z = @(x,t) (exp(t.*2.108e-1i+x.*1.4e-1i).*(-1.2e+1./2.5e+1))./...
            (cosh(t.*(8.4e+1./6.25e+2)-x.*(1.2e+1./2.5e+1)).*...
            (3.0./1.0e+1)-sinh(t.*(8.4e+1./6.25e+2)-x.*(1.2e+1./2.5e+1)).*4.0e-1i);% 精确解
    elseif q == 2
        z = @(x,t) ((exp(t.*(4.8e-2+4.76e-2i)+x.*(2.4e-1-1.0e-1i)).*(1.867867945451913e+19-2.701596826468876e+19i)+exp(t.*(3.3e-2+8.6975e-2i)+x.*(-3.0e-1+5.5e-2i)).*(1.242430547200836e+19+3.581206128689676e+19i)+exp(t.*(4.8e-2-4.76e-2i)+x.*(2.4e-1+1.0e-1i)).*exp(t.*(4.8e-2+4.76e-2i)+x.*(2.4e-1-1.0e-1i)).*exp(t.*(3.3e-2+8.6975e-2i)+x.*(-3.0e-1+5.5e-2i)).*(-1.242430547200836e+19+3.581206128689676e+19i)+exp(t.*(4.8e-2+4.76e-2i)+x.*(2.4e-1-1.0e-1i)).*exp(t.*(3.3e-2-8.6975e-2i)+x.*(-3.0e-1-5.5e-2i)).*exp(t.*(3.3e-2+8.6975e-2i)+x.*(-3.0e-1+5.5e-2i)).*(-1.867867945451913e+19-2.701596826468876e+19i)).*8.526512829121202e-16i)./(exp(t.*(4.8e-2-4.76e-2i)+x.*(2.4e-1+1.0e-1i)).*exp(t.*(4.8e-2+4.76e-2i)+x.*(2.4e-1-1.0e-1i)).*(6.63e+2+6.188e+3i)-exp(t.*(4.8e-2-4.76e-2i)+x.*(2.4e-1+1.0e-1i)).*exp(t.*(3.3e-2+8.6975e-2i)+x.*(-3.0e-1+5.5e-2i)).*7.0272e+4-exp(t.*(4.8e-2+4.76e-2i)+x.*(2.4e-1-1.0e-1i)).*exp(t.*(3.3e-2-8.6975e-2i)+x.*(-3.0e-1-5.5e-2i)).*5.9904e+4+exp(t.*(3.3e-2-8.6975e-2i)+x.*(-3.0e-1-5.5e-2i)).*exp(t.*(3.3e-2+8.6975e-2i)+x.*(-3.0e-1+5.5e-2i)).*(6.63e+2-6.188e+3i)+exp(t.*(4.8e-2-4.76e-2i)+x.*(2.4e-1+1.0e-1i)).*exp(t.*(4.8e-2+4.76e-2i)+x.*(2.4e-1-1.0e-1i)).*exp(t.*(3.3e-2-8.6975e-2i)+x.*(-3.0e-1-5.5e-2i)).*exp(t.*(3.3e-2+8.6975e-2i)+x.*(-3.0e-1+5.5e-2i)).*(6.8175e+4-2.02e+4i)+6.8175e+4+2.02e+4i);
    elseif q == 3
        z = @(x,t)((exp(t.*1.296e-1i+x.*(9.0./2.5e+1)).*(2.79e+2+2.8e+1i)+...
            exp(t.*(1.344e-1+2.108e-1i)+x.*(4.8e-1-1.4e-1i)).*(-3.16e+2+2.8e+1i)+...
            exp(t.*-1.296e-1i+x.*(9.0./2.5e+1)).*exp(t.*1.296e-1i+x.*(9.0./2.5e+1)).*...
            exp(t.*(1.344e-1+2.108e-1i)+x.*(4.8e-1-1.4e-1i)).*(3.16e+2+2.8e+1i)+...
            exp(t.*1.296e-1i+x.*(9.0./2.5e+1)).*exp(t.*(1.344e-1-2.108e-1i)+x.*...
            (4.8e-1+1.4e-1i)).*exp(t.*(1.344e-1+2.108e-1i)+x.*(4.8e-1-1.4e-1i)).*...
            (-2.79e+2+2.8e+1i)).*1.68e+1i)./(exp(t.*-1.296e-1i+x.*(9.0./2.5e+1)).*...
            exp(t.*1.296e-1i+x.*(9.0./2.5e+1)).*(1.2691e+4+1.813e+3i)-exp(t.*-1.296e-1i+...
            x.*(9.0./2.5e+1)).*exp(t.*(1.344e-1+2.108e-1i)+x.*(4.8e-1-1.4e-1i)).*1.44e+4-...
            exp(t.*1.296e-1i+x.*(9.0./2.5e+1)).*exp(t.*(1.344e-1-2.108e-1i)+x.*...
            (4.8e-1+1.4e-1i)).*1.0368e+4+exp(t.*(1.344e-1-2.108e-1i)+x.*(4.8e-1+...
            1.4e-1i)).*exp(t.*(1.344e-1+2.108e-1i)+x.*(4.8e-1-1.4e-1i)).*(1.2691e+4-1.813e+3i)+...
            exp(t.*-1.296e-1i+x.*(9.0./2.5e+1)).*exp(t.*1.296e-1i+x.*(9.0./2.5e+1)).*...
            exp(t.*(1.344e-1-2.108e-1i)+x.*(4.8e-1+1.4e-1i)).*exp(t.*(1.344e-1+2.108e-1i)+...
            x.*(4.8e-1-1.4e-1i)).*(8.5e+1+5.95e+2i)+8.5e+1-5.95e+2i);
    elseif q == 4
        z = @(x,t) ((exp(t.*(9.6e-2-6.44e-2i)+x.*(1.6e-1-3.0e-1i)).*(1.527801137589167e+21-6.593269854470407e+19i)+exp(t.*(2.1e-2-1.025e-3i)+x.*(-1.0e-1+1.05e-1i)).*(6.664877088545597e+20+1.302981444190832e+21i)+exp(t.*(9.6e-2-6.44e-2i)+x.*(1.6e-1-3.0e-1i)).*exp(t.*(9.6e-2+6.44e-2i)+x.*(1.6e-1+3.0e-1i)).*exp(t.*(2.1e-2-1.025e-3i)+x.*(-1.0e-1+1.05e-1i)).*(-6.664877088545597e+20+1.302981444190832e+21i)+exp(t.*(9.6e-2-6.44e-2i)+x.*(1.6e-1-3.0e-1i)).*exp(t.*(2.1e-2-1.025e-3i)+x.*(-1.0e-1+1.05e-1i)).*exp(t.*(2.1e-2+1.025e-3i)+x.*(-1.0e-1-1.05e-1i)).*(-1.527801137589167e+21-6.593269854470407e+19i)).*1.77635683940025e-17i)./(exp(t.*(9.6e-2-6.44e-2i)+x.*(1.6e-1-3.0e-1i)).*exp(t.*(9.6e-2+6.44e-2i)+x.*(1.6e-1+3.0e-1i)).*(4.023e+3+2.9502e+4i)-exp(t.*(9.6e-2-6.44e-2i)+x.*(1.6e-1-3.0e-1i)).*exp(t.*(2.1e-2+1.025e-3i)+x.*(-1.0e-1-1.05e-1i)).*1.7408e+4-exp(t.*(9.6e-2+6.44e-2i)+x.*(1.6e-1+3.0e-1i)).*exp(t.*(2.1e-2-1.025e-3i)+x.*(-1.0e-1+1.05e-1i)).*7.424e+3+exp(t.*(2.1e-2-1.025e-3i)+x.*(-1.0e-1+1.05e-1i)).*exp(t.*(2.1e-2+1.025e-3i)+x.*(-1.0e-1-1.05e-1i)).*(4.023e+3-2.9502e+4i)+exp(t.*(9.6e-2-6.44e-2i)+x.*(1.6e-1-3.0e-1i)).*exp(t.*(9.6e-2+6.44e-2i)+x.*(1.6e-1+3.0e-1i)).*exp(t.*(2.1e-2-1.025e-3i)+x.*(-1.0e-1+1.05e-1i)).*exp(t.*(2.1e-2+1.025e-3i)+x.*(-1.0e-1-1.05e-1i)).*(2.4089e+4-3.3354e+4i)+2.4089e+4+3.3354e+4i);
    end
    u = zeros(m+1,n+1);Err = u;
    u(:,1) = z(x,t(1));u(1,:) = z(x(1),t);u(m+1,:) = z(x(m+1),t);
%%  空间方向  
    %% 谱微分矩阵对应向量
    [Lam1,Lam2] = DS(m,L);Lam0 = 1i*ht*Lam2;
%% 时间方向
    %% 高斯配置-隐式龙格库塔方法
    if s == 1
        A = 1/2;
        b = 1;
    elseif s == 2
        A = [1/4 1/4-sqrt(3)/6;1/4+sqrt(3)/6 1/4];
        b = [1/2 1/2];
    elseif s == 3
        A = [5/36 2/9-sqrt(15)/15 5/36-sqrt(15)/30;
            5/36+sqrt(15)/24 2/9 5/36-sqrt(15)/24;
            5/36+sqrt(15)/30 2/9+sqrt(15)/15 5/36];
        b = [5/18 4/9 5/18];
    elseif s == 4
        A = double([sqrt(sym(30))/144 + sym(1/8), sqrt(sym(30))/144 - (sqrt(sym(42))*sqrt(15 - 2*sqrt(sym(30))))/168 - (sqrt(sym(35))*sqrt(15 - 2*sqrt(sym(30))))/105 + sym(1/8), (23*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(6*sqrt(sym(30)) + 45)/42 - sqrt(sym(30))/144 + sqrt(70*sqrt(sym(30)) + 525)/1470 + (5*sqrt(84*sqrt(sym(30)) + 630))/2352 + sym(1/8), (23*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(6*sqrt(sym(30)) + 45)/42 - sqrt(sym(30))/144 - sqrt(70*sqrt(sym(30)) + 525)/1470 - (5*sqrt(84*sqrt(sym(30)) + 630))/2352 + sym(1/8); (sqrt(sym(35))*sqrt(15 - 2*sqrt(sym(30))))/105 + (sqrt(sym(42))*sqrt(15 - 2*sqrt(sym(30))))/168 + sqrt(sym(30))/144 + sym(1/8), sqrt(sym(30))/144 + sym(1/8), sqrt(6*sqrt(sym(30)) + 45)/42 - sqrt(sym(30))/144 - (23*sqrt(20*sqrt(sym(30)) + 150))/1680 + sqrt(70*sqrt(sym(30)) + 525)/1470 + (5*sqrt(84*sqrt(sym(30)) + 630))/2352 + sym(1/8), sqrt(6*sqrt(sym(30)) + 45)/42 - sqrt(sym(30))/144 - (23*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(70*sqrt(sym(30)) + 525)/1470 - (5*sqrt(84*sqrt(sym(30)) + 630))/2352 + sym(1/8); sqrt(sym(30))/144 + sqrt(6*sqrt(sym(30)) + 45)/84 - (13*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(70*sqrt(sym(30)) + 525)/420 - sqrt(84*sqrt(sym(30)) + 630)/336 + sym(1/8), sqrt(sym(30))/144 - sqrt(6*sqrt(sym(30)) + 45)/84 + (13*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(70*sqrt(sym(30)) + 525)/420 - sqrt(84*sqrt(sym(30)) + 630)/336 + sym(1/8), sym(1/8) - sqrt(sym(30))/144, (sqrt(sym(42))*sqrt(2*sqrt(sym(30)) + 15))/168 - (sqrt(sym(35))*sqrt(2*sqrt(sym(30)) + 15))/105 - sqrt(sym(30))/144 + sym(1/8); sqrt(sym(30))/144 + sqrt(6*sqrt(sym(30)) + 45)/84 - (13*sqrt(20*sqrt(sym(30)) + 150))/1680 + sqrt(70*sqrt(sym(30)) + 525)/420 + sqrt(84*sqrt(sym(30)) + 630)/336 + sym(1/8), sqrt(sym(30))/144 - sqrt(6*sqrt(sym(30)) + 45)/84 + (13*sqrt(20*sqrt(sym(30)) + 150))/1680 + sqrt(70*sqrt(sym(30)) + 525)/420 + sqrt(84*sqrt(sym(30)) + 630)/336 + sym(1/8), (sqrt(sym(35))*sqrt(2*sqrt(sym(30)) + 15))/105 - (sqrt(sym(42))*sqrt(2*sqrt(sym(30)) + 15))/168 - sqrt(sym(30))/144 + sym(1/8), sym(1/8) - sqrt(sym(30))/144]);
        b = double([sqrt(sym(30))/72 + sym(1/4), sqrt(sym(30))/72 + sym(1/4), sym(1/4) - sqrt(sym(30))/72, sym(1/4) - sqrt(sym(30))/72]);
    elseif s == 5
        A = double([sym(32/225), (13*sqrt(sym(70)))/3600 + (11*sqrt(245 - 14*sqrt(sym(70))))/1440 + (23*sqrt(350 - 20*sqrt(sym(70))))/5760 + sym(161/1800), (13*sqrt(sym(70)))/3600 - (11*sqrt(245 - 14*sqrt(sym(70))))/1440 - (23*sqrt(350 - 20*sqrt(sym(70))))/5760 + sym(161/1800), (11*sqrt(14*sqrt(sym(70)) + 245))/1440 - (13*sqrt(sym(70)))/3600 - (23*sqrt(20*sqrt(sym(70)) + 350))/5760 + sym(161/1800), (23*sqrt(20*sqrt(sym(70)) + 350))/5760 - (11*sqrt(14*sqrt(sym(70)) + 245))/1440 - (13*sqrt(sym(70)))/3600 + sym(161/1800); sym(32/225) - (4*sqrt(350 - 20*sqrt(sym(70))))/1215 - (92*sqrt(245 - 14*sqrt(sym(70))))/8505, (13*sqrt(sym(70)))/3600 + sym(161/1800), (13*sqrt(sym(70)))/3600 - (2*sqrt(245 - 14*sqrt(sym(70))))/315 - sqrt(350 - 20*sqrt(sym(70)))/360 + sym(161/1800), (4*sqrt(14*sqrt(sym(70)) + 245))/2835 - (13*sqrt(sym(70)))/3600 + (11*sqrt(20*sqrt(sym(70)) + 350))/6480 - (43*sqrt(30*sqrt(sym(70)) + 525))/10935 + (2969*sqrt(84*sqrt(sym(70)) + 1470))/1224720 + sym(161/1800), (2969*sqrt(84*sqrt(sym(70)) + 1470))/1224720 - (4*sqrt(14*sqrt(sym(70)) + 245))/2835 - (11*sqrt(20*sqrt(sym(70)) + 350))/6480 - (43*sqrt(30*sqrt(sym(70)) + 525))/10935 - (13*sqrt(sym(70)))/3600 + sym(161/1800); (92*sqrt(245 - 14*sqrt(sym(70))))/8505 + (4*sqrt(350 - 20*sqrt(sym(70))))/1215 + sym(32/225), (13*sqrt(sym(70)))/3600 + (2*sqrt(245 - 14*sqrt(sym(70))))/315 + sqrt(350 - 20*sqrt(sym(70)))/360 + sym(161/1800), (13*sqrt(sym(70)))/3600 + sym(161/1800), (4*sqrt(14*sqrt(sym(70)) + 245))/2835 - (13*sqrt(sym(70)))/3600 + (11*sqrt(20*sqrt(sym(70)) + 350))/6480 + (43*sqrt(30*sqrt(sym(70)) + 525))/10935 - (2969*sqrt(84*sqrt(sym(70)) + 1470))/1224720 + sym(161/1800), (43*sqrt(30*sqrt(sym(70)) + 525))/10935 - (4*sqrt(14*sqrt(sym(70)) + 245))/2835 - (11*sqrt(20*sqrt(sym(70)) + 350))/6480 - (13*sqrt(sym(70)))/3600 - (2969*sqrt(84*sqrt(sym(70)) + 1470))/1224720 + sym(161/1800); (4*sqrt(20*sqrt(sym(70)) + 350))/1215 - (92*sqrt(14*sqrt(sym(70)) + 245))/8505 + sym(32/225), (13*sqrt(sym(70)))/3600 - (113*sqrt(14*sqrt(sym(70)) + 245))/34020 - (59*sqrt(20*sqrt(sym(70)) + 350))/19440 + sqrt(30*sqrt(sym(70)) + 525)/540 - (19*sqrt(84*sqrt(sym(70)) + 1470))/15120 + sym(161/1800), (13*sqrt(sym(70)))/3600 - (113*sqrt(14*sqrt(sym(70)) + 245))/34020 - (59*sqrt(20*sqrt(sym(70)) + 350))/19440 - sqrt(30*sqrt(sym(70)) + 525)/540 + (19*sqrt(84*sqrt(sym(70)) + 1470))/15120 + sym(161/1800), sym(161/1800) - (13*sqrt(sym(70)))/3600, sqrt(20*sqrt(sym(70)) + 350)/360 - (2*sqrt(14*sqrt(sym(70)) + 245))/315 - (13*sqrt(sym(70)))/3600 + sym(161/1800); (92*sqrt(14*sqrt(sym(70)) + 245))/8505 - (4*sqrt(20*sqrt(sym(70)) + 350))/1215 + sym(32/225), (13*sqrt(sym(70)))/3600 + (113*sqrt(14*sqrt(sym(70)) + 245))/34020 + (59*sqrt(20*sqrt(sym(70)) + 350))/19440 + sqrt(30*sqrt(sym(70)) + 525)/540 - (19*sqrt(84*sqrt(sym(70)) + 1470))/15120 + sym(161/1800), (13*sqrt(sym(70)))/3600 + (113*sqrt(14*sqrt(sym(70)) + 245))/34020 + (59*sqrt(20*sqrt(sym(70)) + 350))/19440 - sqrt(30*sqrt(sym(70)) + 525)/540 + (19*sqrt(84*sqrt(sym(70)) + 1470))/15120 + sym(161/1800), (2*sqrt(14*sqrt(sym(70)) + 245))/315 - (13*sqrt(sym(70)))/3600 - sqrt(20*sqrt(sym(70)) + 350)/360 + sym(161/1800), sym(161/1800) - (13*sqrt(sym(70)))/3600]);
        b = double([sym(64/225), (13*sqrt(sym(70)))/1800 + sym(161/900), (13*sqrt(sym(70)))/1800 + sym(161/900), sym(161/900) - (13*sqrt(sym(70)))/1800, sym(161/900) - (13*sqrt(sym(70)))/1800]);
    elseif s == 6
        A = [1/4 0;1/2 1/4];
        b = [1/2 1/2];s = length(b);
    end
    %% 循环求解过程所用矩阵系数
    J = (eye(s)-sym("x")*A)\eye(s);
    F = kron(ones(s),zeros(m,1));
    for i = 1:s
        for j = 1:s
            if J(i,j) ~= 0
                J1 = matlabFunction(J(i,j));
                F((i-1)*m+1:i*m,j) = J1(Lam0);
            else
                F((i-1)*m+1:i*m,j) = 0*Lam0;
            end
        end
    end
    %% 守恒律的初始值
    E = zeros(1,n+1);P = zeros(1,n+1);M = zeros(1,n+1);V = zeros(1,n+1);
    D2u1 = dfft(u(1:m,1),Lam2);D1u2 = dfft(u(1:m,1).^2,Lam1);
    E(1) = -dispord(u(1:m,1),D2u1,hx)-1/4*imag( dispord(u(1:m,1).^2,D1u2,hx) );
    P(1) = imag(dispord(u(1:m,1),dfft(u(1:m,1),Lam1),hx));
    M(1) = hx*sum(abs(u(1:m,1).^2));
    V(1) = real(sqrt( 1/4*imag( dispord(u(1:m,1).^2,D1u2,hx) )+E(1) ));
    ep = 0.5e-12;% 允许最大误差精度
    for k = 1:n
        str=['计算中...',num2str(100*(k-1)/n),'%','(',num2str((k-1)),'/',num2str(n),')',';','当前耗时',num2str(toc),'秒'];    % 百分比形式显示处理进程,不需要删掉这行代码就行
        waitbar((k-1)/n,bar,str)                       % 更新进度条bar，配合bar使用
        %% 初始值
        U0 = u(1:m,k);
        D1U2 = dfft(U0.^2,Lam1);D2U1 = dfft(U0,Lam2);
        v0 = V(k);
        f0 = 1i*D2U1-1/2*(conj(U0).*(D1U2));
        %% 主要迭代变量
        f = kron(ones(1,s),f0);
        g = zeros(s,1);
        U = kron(ones(1,s),U0);
        Q = kron(ones(1,s),zeros(size(U0)));
        while 1
            temp = f;
            for j = 1:s
                U(:,j) = U0+ht*sum(A(j,:).*f,2);
                D1U2 = dfft(U(:,j).^2,Lam1);
                V = sqrt( 1/4*imag(dispord(U(:,j).^2,D1U2,hx))+E(1) );
                g(j) = real(imag(dispord(U(:,j).*f(:,j),D1U2,hx))/2/V);
                Q(:,j) = 1/2*(conj(U(:,j)).*(D1U2))/V;
            end
            v = v0+ht*A*g;
            w = 1i*dfft(U0,Lam2)-Q.*v';
            %% 矩阵求解
            f = ifft(reshape(sum(F.*kron(ones(s,1),fft(w)),2),[],s));
            err = max(abs(f-temp));
            if err <= ep
                break;
            end
        end
        u(1:m,k+1) = (U0+ht*sum(b.*f,2));Err(1:m,k+1) = abs(u(1:m,k+1)-z(x(1:m),t(k+1)));
        V(k+1) = v0+ht*sum(b*g,2);
        E(k+1) = -dispord(u(1:m,k+1),dfft(u(1:m,k+1),Lam2),hx)-( V(k+1)^2 )+E(1);
        P(k+1) = imag(dispord(u(1:m,k+1),dfft(u(1:m,k+1),Lam1),hx));
        M(k+1) = hx*sum(abs(u(1:m,k+1).^2));
    end
    close(bar)
    if pic == 1
        figure(1)
        imagesc(x,t+t(end),abs(u'))
        xlabel("$x$","Interpreter","latex","FontSize",20)
        ylabel("$t$","Interpreter","latex","FontSize",20)
        title("$|u|$","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
        figure(2)
        plot(t+t(end),abs(M-M(1)),"r--","LineWidth",2)
        xlabel("$t_k$","Interpreter","latex","FontSize",20)
        ylabel("$|M_{1,h}^k-M_{1,h}^0|$","Interpreter","latex","FontSize",20)
        set(gca,'YScale','log') 
        title(" Errors of $M_{1,h}^k$ ","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
%         legend('$h = \frac{1}{10},\,\tau = \frac{1}{100}$','Interpreter','latex',"Location","southeast")
        hold on
        figure(3)
        plot(t+t(end),abs(E-E(1)),"r--","LineWidth",2)
        xlabel("$t_k$","Interpreter","latex","FontSize",20)
        ylabel("$|H_{h}^k-H_{h}^0|$","Interpreter","latex","FontSize",20)
        set(gca,'YScale','log') 
        title(" Errors of $H_{h}^k$ ","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
%         legend('$h = \frac{1}{10},\,\tau = \frac{1}{100}$','Interpreter','latex',"Location","southeast")
        hold on
        figure(4)
        plot(t+t(end),abs(P-P(1)),"r--","LineWidth",2)
        xlabel("$t_k$","Interpreter","latex","FontSize",20)
        ylabel("$|M_{2,h}^k-M_{2,h}^0|$","Interpreter","latex","FontSize",20)
        set(gca,'YScale','log') 
        title(" Errors of $M_{2,h}^k$ ","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
%         legend('$h = \frac{1}{10},\,\tau = \frac{1}{100}$','Interpreter','latex',"Location","southeast")
        hold on
        figure(5)
        plot(t+t(end),M,"r-",t+t(end),P,"g-",t+t(end),E,"b-","LineWidth",2)
        xlabel("$t_k$","Interpreter","latex","FontSize",20)
        legend("$M_{1,h}^k$","$M_{2,h}^k$","$H_{h}^k$","Interpreter","latex","FontSize",20)
    end
%%  附录函数
    %% dispord：离散内积函数
    function I = dispord(u,v,h)
        I = (h*sum(u.*conj(v)));
    end
    %% DS: 谱微分矩阵
    function [Lam1,Lam2] = DS(m,L)
        lambda = 2*pi/L;
        r1 = (zeros(m,1));  
        r1(1:m/2) = 0:m/2-1; r1(m/2+2:m) = -m/2+1:-1;
        r2 = r1; r2(m/2+1) = m/2;
        Lam1 = (1i * lambda * r1);
        Lam2 = (1i * lambda * r2).^2;
    end
    %% fun: 基于快速傅里叶变换的微分矩阵
    function y = dfft(u,s)
        y = ifft(s.*fft(u)); 
    end
end