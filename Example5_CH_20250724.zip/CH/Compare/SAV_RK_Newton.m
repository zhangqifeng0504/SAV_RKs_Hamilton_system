function [u,E,M,P,H,x,t] = SAV_RK_Newton(m,n,s,q,pic)
%UNTITLED3 此处提供此函数的摘要
%   此处提供详细说明
    bar = waitbar(0,'please wait...');
    %% 网格划分
    xa = 0;xb = 30;L = abs(xb-xa);hx = L/m;x = xa:hx:xb;x = x';
    ta = 0;tb = 10;ht = abs(tb-ta)/n;t = ta:ht:tb;
    [X,T] = meshgrid(x,t);
    %% 真解和初边值条件
    if q == 1
        c = 1;L = 1;x_0 = 0;
        u0 = @(x) (abs(x-x_0)<=L/2).*cosh(x-x_0)*(c/cosh(L/2))+(abs(x-x_0)>L/2).*cosh(L-(x-x_0))*(c/cosh(L/2));
    elseif q == 2
        c = [2 1 0.8];x_0 = [-5 -3 -1];L = 30;
        u0 = @(x)(abs(x-x_0(1))<=L/2).*cosh(x-x_0(1))*(c(1)/cosh(L/2))...
                +(abs(x-x_0(1))>L/2).*cosh(L-(x-x_0(1)))*(c(1)/cosh(L/2))...
                +(abs(x-x_0(2))<=L/2).*cosh(x-x_0(2))*(c(2)/cosh(L/2))...
                +(abs(x-x_0(2))>L/2).*cosh(L-(x-x_0(2)))*(c(2)/cosh(L/2))...
                +(abs(x-x_0(3))<=L/2).*cosh(x-x_0(3))*(c(3)/cosh(L/2))...
                +(abs(x-x_0(3))>L/2).*cosh(L-(x-x_0(3)))*(c(3)/cosh(L/2));
    elseif q == 3
        u0 = @(x)  sin(x);
    end
    u = zeros(m+1,n+1);
    u(:,1) = u0(x);
%%  空间方向  
    %% 谱微分矩阵对应向量
    [Lam1,Lam2] = DS(m,L);Lam0 = 2*ht*Lam1;Lam = (1-Lam2).\Lam1;
%% 时间方向
    %% 高斯配置-隐式龙格库塔方法
    if s == 1
        A = 1/2;
        b = 1;
    elseif s == 2
        A = [1/4 1/4-sqrt(3)/6;1/4+sqrt(3)/6 1/4];
        b = [1/2 1/2];
    elseif s == 3
        A = [5/36 2/9-sqrt(15)/15 5/36-sqrt(15)/30;
            5/36+sqrt(15)/24 2/9 5/36-sqrt(15)/24;
            5/36+sqrt(15)/30 2/9+sqrt(15)/15 5/36];
        b = [5/18 4/9 5/18];
    elseif s == 4
        A = double([sqrt(sym(30))/144 + sym(1/8), sqrt(sym(30))/144 - (sqrt(sym(42))*sqrt(15 - 2*sqrt(sym(30))))/168 - (sqrt(sym(35))*sqrt(15 - 2*sqrt(sym(30))))/105 + sym(1/8), (23*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(6*sqrt(sym(30)) + 45)/42 - sqrt(sym(30))/144 + sqrt(70*sqrt(sym(30)) + 525)/1470 + (5*sqrt(84*sqrt(sym(30)) + 630))/2352 + sym(1/8), (23*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(6*sqrt(sym(30)) + 45)/42 - sqrt(sym(30))/144 - sqrt(70*sqrt(sym(30)) + 525)/1470 - (5*sqrt(84*sqrt(sym(30)) + 630))/2352 + sym(1/8); (sqrt(sym(35))*sqrt(15 - 2*sqrt(sym(30))))/105 + (sqrt(sym(42))*sqrt(15 - 2*sqrt(sym(30))))/168 + sqrt(sym(30))/144 + sym(1/8), sqrt(sym(30))/144 + sym(1/8), sqrt(6*sqrt(sym(30)) + 45)/42 - sqrt(sym(30))/144 - (23*sqrt(20*sqrt(sym(30)) + 150))/1680 + sqrt(70*sqrt(sym(30)) + 525)/1470 + (5*sqrt(84*sqrt(sym(30)) + 630))/2352 + sym(1/8), sqrt(6*sqrt(sym(30)) + 45)/42 - sqrt(sym(30))/144 - (23*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(70*sqrt(sym(30)) + 525)/1470 - (5*sqrt(84*sqrt(sym(30)) + 630))/2352 + sym(1/8); sqrt(sym(30))/144 + sqrt(6*sqrt(sym(30)) + 45)/84 - (13*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(70*sqrt(sym(30)) + 525)/420 - sqrt(84*sqrt(sym(30)) + 630)/336 + sym(1/8), sqrt(sym(30))/144 - sqrt(6*sqrt(sym(30)) + 45)/84 + (13*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(70*sqrt(sym(30)) + 525)/420 - sqrt(84*sqrt(sym(30)) + 630)/336 + sym(1/8), sym(1/8) - sqrt(sym(30))/144, (sqrt(sym(42))*sqrt(2*sqrt(sym(30)) + 15))/168 - (sqrt(sym(35))*sqrt(2*sqrt(sym(30)) + 15))/105 - sqrt(sym(30))/144 + sym(1/8); sqrt(sym(30))/144 + sqrt(6*sqrt(sym(30)) + 45)/84 - (13*sqrt(20*sqrt(sym(30)) + 150))/1680 + sqrt(70*sqrt(sym(30)) + 525)/420 + sqrt(84*sqrt(sym(30)) + 630)/336 + sym(1/8), sqrt(sym(30))/144 - sqrt(6*sqrt(sym(30)) + 45)/84 + (13*sqrt(20*sqrt(sym(30)) + 150))/1680 + sqrt(70*sqrt(sym(30)) + 525)/420 + sqrt(84*sqrt(sym(30)) + 630)/336 + sym(1/8), (sqrt(sym(35))*sqrt(2*sqrt(sym(30)) + 15))/105 - (sqrt(sym(42))*sqrt(2*sqrt(sym(30)) + 15))/168 - sqrt(sym(30))/144 + sym(1/8), sym(1/8) - sqrt(sym(30))/144]);
        b = double([sqrt(sym(30))/72 + sym(1/4), sqrt(sym(30))/72 + sym(1/4), sym(1/4) - sqrt(sym(30))/72, sym(1/4) - sqrt(sym(30))/72]);
    elseif s == 5
        A = double([sym(32/225), (13*sqrt(sym(70)))/3600 + (11*sqrt(245 - 14*sqrt(sym(70))))/1440 + (23*sqrt(350 - 20*sqrt(sym(70))))/5760 + sym(161/1800), (13*sqrt(sym(70)))/3600 - (11*sqrt(245 - 14*sqrt(sym(70))))/1440 - (23*sqrt(350 - 20*sqrt(sym(70))))/5760 + sym(161/1800), (11*sqrt(14*sqrt(sym(70)) + 245))/1440 - (13*sqrt(sym(70)))/3600 - (23*sqrt(20*sqrt(sym(70)) + 350))/5760 + sym(161/1800), (23*sqrt(20*sqrt(sym(70)) + 350))/5760 - (11*sqrt(14*sqrt(sym(70)) + 245))/1440 - (13*sqrt(sym(70)))/3600 + sym(161/1800); sym(32/225) - (4*sqrt(350 - 20*sqrt(sym(70))))/1215 - (92*sqrt(245 - 14*sqrt(sym(70))))/8505, (13*sqrt(sym(70)))/3600 + sym(161/1800), (13*sqrt(sym(70)))/3600 - (2*sqrt(245 - 14*sqrt(sym(70))))/315 - sqrt(350 - 20*sqrt(sym(70)))/360 + sym(161/1800), (4*sqrt(14*sqrt(sym(70)) + 245))/2835 - (13*sqrt(sym(70)))/3600 + (11*sqrt(20*sqrt(sym(70)) + 350))/6480 - (43*sqrt(30*sqrt(sym(70)) + 525))/10935 + (2969*sqrt(84*sqrt(sym(70)) + 1470))/1224720 + sym(161/1800), (2969*sqrt(84*sqrt(sym(70)) + 1470))/1224720 - (4*sqrt(14*sqrt(sym(70)) + 245))/2835 - (11*sqrt(20*sqrt(sym(70)) + 350))/6480 - (43*sqrt(30*sqrt(sym(70)) + 525))/10935 - (13*sqrt(sym(70)))/3600 + sym(161/1800); (92*sqrt(245 - 14*sqrt(sym(70))))/8505 + (4*sqrt(350 - 20*sqrt(sym(70))))/1215 + sym(32/225), (13*sqrt(sym(70)))/3600 + (2*sqrt(245 - 14*sqrt(sym(70))))/315 + sqrt(350 - 20*sqrt(sym(70)))/360 + sym(161/1800), (13*sqrt(sym(70)))/3600 + sym(161/1800), (4*sqrt(14*sqrt(sym(70)) + 245))/2835 - (13*sqrt(sym(70)))/3600 + (11*sqrt(20*sqrt(sym(70)) + 350))/6480 + (43*sqrt(30*sqrt(sym(70)) + 525))/10935 - (2969*sqrt(84*sqrt(sym(70)) + 1470))/1224720 + sym(161/1800), (43*sqrt(30*sqrt(sym(70)) + 525))/10935 - (4*sqrt(14*sqrt(sym(70)) + 245))/2835 - (11*sqrt(20*sqrt(sym(70)) + 350))/6480 - (13*sqrt(sym(70)))/3600 - (2969*sqrt(84*sqrt(sym(70)) + 1470))/1224720 + sym(161/1800); (4*sqrt(20*sqrt(sym(70)) + 350))/1215 - (92*sqrt(14*sqrt(sym(70)) + 245))/8505 + sym(32/225), (13*sqrt(sym(70)))/3600 - (113*sqrt(14*sqrt(sym(70)) + 245))/34020 - (59*sqrt(20*sqrt(sym(70)) + 350))/19440 + sqrt(30*sqrt(sym(70)) + 525)/540 - (19*sqrt(84*sqrt(sym(70)) + 1470))/15120 + sym(161/1800), (13*sqrt(sym(70)))/3600 - (113*sqrt(14*sqrt(sym(70)) + 245))/34020 - (59*sqrt(20*sqrt(sym(70)) + 350))/19440 - sqrt(30*sqrt(sym(70)) + 525)/540 + (19*sqrt(84*sqrt(sym(70)) + 1470))/15120 + sym(161/1800), sym(161/1800) - (13*sqrt(sym(70)))/3600, sqrt(20*sqrt(sym(70)) + 350)/360 - (2*sqrt(14*sqrt(sym(70)) + 245))/315 - (13*sqrt(sym(70)))/3600 + sym(161/1800); (92*sqrt(14*sqrt(sym(70)) + 245))/8505 - (4*sqrt(20*sqrt(sym(70)) + 350))/1215 + sym(32/225), (13*sqrt(sym(70)))/3600 + (113*sqrt(14*sqrt(sym(70)) + 245))/34020 + (59*sqrt(20*sqrt(sym(70)) + 350))/19440 + sqrt(30*sqrt(sym(70)) + 525)/540 - (19*sqrt(84*sqrt(sym(70)) + 1470))/15120 + sym(161/1800), (13*sqrt(sym(70)))/3600 + (113*sqrt(14*sqrt(sym(70)) + 245))/34020 + (59*sqrt(20*sqrt(sym(70)) + 350))/19440 - sqrt(30*sqrt(sym(70)) + 525)/540 + (19*sqrt(84*sqrt(sym(70)) + 1470))/15120 + sym(161/1800), (2*sqrt(14*sqrt(sym(70)) + 245))/315 - (13*sqrt(sym(70)))/3600 - sqrt(20*sqrt(sym(70)) + 350)/360 + sym(161/1800), sym(161/1800) - (13*sqrt(sym(70)))/3600]);
        b = double([sym(64/225), (13*sqrt(sym(70)))/1800 + sym(161/900), (13*sqrt(sym(70)))/1800 + sym(161/900), sym(161/900) - (13*sqrt(sym(70)))/1800, sym(161/900) - (13*sqrt(sym(70)))/1800]);
    end
    %% 循环求解过程所用矩阵系数
    J = (eye(s)-sym("x")*A)\eye(s);
    F = kron(ones(s),zeros(m,1));
    for i = 1:s
        for j = 1:s
            J1 = matlabFunction(J(i,j));
            F((i-1)*m+1:i*m,j) = J1(Lam0);
        end
    end
    %% 初始守恒律
    M = zeros(1,n+1);P = M;E = M;V = M;H = E;
    D1u1 = dfft(u(1:m,1),Lam1);
    M(1) = dispord(u(1:m,1),u(1:m,1),hx)+dispord(D1u1,D1u1,hx);
    P(1) = dispord(u(1:m,1),1,hx);
    E(1) = -1/2*dispord(u(1:m,1),u(1:m,1).^2+D1u1.^2,hx);H(1) = E(1);
    V(1) = sqrt(dispord(u(1:m,1),u(1:m,1),hx));
    ep = 1e-12;% 允许最大误差精度
    tic
    for k = 1:n
        str=['计算中...',num2str(100*(k-1)/n),'%','(',num2str((k-1)),'/',num2str(n),')',';','当前耗时',num2str(toc),'秒'];    % 百分比形式显示处理进程,不需要删掉这行代码就行
        waitbar((k-1)/n,bar,str)                       % 更新进度条bar，配合bar使用
        %% 初始值
        U0 = u(1:m,k);D1U1 = dfft(U0,Lam1);D2U1 = dfft(U0,Lam2);
        v0 = V(k);
        Q0 = U0.*D2U1+1/2*D1U1.^2-3/2*U0.^2;
        f0 = dfft(Q0,Lam);
        %% 主要迭代变量
        f = kron(ones(1,s),f0);
        while 1
            U = reshape(kron(ones(s,1),U0)+ht*sum(kron(A,ones(m,1)).*kron(ones(s,1),f),2),[],s);
            D1U1 = dfft(U,Lam1);D2U1 = dfft(U,Lam2);
            H_temp = -1/2*dispord(U,U.^2+D1U1.^2,hx);
            M_temp = dispord(U,U,hx);
            V_temp = sqrt(E(1)-H_temp+M_temp);
            Q = (U.*D2U1+1/2*D1U1.^2-3/2*U.^2-2*U)./V_temp;
            g = -1/2*dispord(f,Q,hx);
            v = v0+ht*A*g';
            w = f -(dfft(2*U+Q.*v',Lam));
            %% 矩阵求解
            err = -ifft(reshape(sum(F.*kron(ones(s,1),fft(w)),2),[],s));
            f = f+err;
            %% 循环跳出判断
            if abs(err) <= 1e-12
                break;
            end
        end
        u(1:m,k+1) = (U0+ht*sum(b.*f,2));D1u1 = dfft(u(1:m,k+1),Lam1);
        V(k+1) = v0+ht*b*g';
        P(k+1) = dispord(u(1:m,k+1),1,hx);
        M(k+1) = dispord(u(1:m,k+1),u(1:m,k+1),hx)+dispord(D1u1,D1u1,hx);
        E(k+1) = -(V(k+1))^2+dispord(u(1:m,k+1),u(1:m,k+1),hx)+E(1);
        H(k+1) = -1/2*dispord(u(1:m,k+1),u(1:m,k+1).^2+D1u1.^2,hx);
    end
    close(bar)
    %% 验证质量，能量守恒
    if pic == 1
        figure(1)
        imagesc(x,t,(u'))
        xlabel("$x$","Interpreter","latex","FontSize",20)
        ylabel("$t$","Interpreter","latex","FontSize",20)
        title("$|u|$","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
        figure(2)
        plot(t,abs(M-M(1)),"r--","LineWidth",2)
        hold on
        plot(t,abs(V-V(1)),"g--","LineWidth",2)
        xlabel("$t_k$","Interpreter","latex","FontSize",20)
        ylabel("$|M^k-M^0|$","Interpreter","latex","FontSize",20)
        set(gca,'YScale','log') 
        title(" Errors of $M_{1,h}^k$ ","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
%         legend('$h = \frac{1}{10},\,\tau = \frac{1}{100}$','Interpreter','latex',"Location","southeast")
        hold on
        figure(3)
        plot(t,abs(E-E(1)),"--","LineWidth",2)
        xlabel("$t_k$","Interpreter","latex","FontSize",20)
        ylabel("$|H^k-H^0|$","Interpreter","latex","FontSize",20)
        set(gca,'YScale','log') 
        title(" Errors of $M_{3,h}^k$ ","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
%         legend('$h = \frac{1}{10},\,\tau = \frac{1}{100}$','Interpreter','latex',"Location","southeast")
        hold on
        figure(4)
        plot(t,abs(P-P(1)),"--","LineWidth",2)
        xlabel("$t_k$","Interpreter","latex","FontSize",20)
        ylabel("$|P^k-P^0|$","Interpreter","latex","FontSize",20)
        set(gca,'YScale','log') 
        title(" Errors of $M_{2,h}^k$ ","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
%         legend('$h = \frac{1}{10},\,\tau = \frac{1}{100}$','Interpreter','latex',"Location","southeast")
        hold on
        figure(5)
        plot(t,M,"r-",t,P,"g--",t,E,"b-","LineWidth",2)
        xlabel("$t_k$","Interpreter","latex","FontSize",20)
        legend("M^k","P^k","H^k")
        figure(6)
        mesh(X(1:50:end,1:50:end),T(1:50:end,1:50:end),(u(1:50:end,1:50:end)'))
        xlabel("$x$","Interpreter","latex","FontSize",20)
        ylabel("$t$","Interpreter","latex","FontSize",20)
        zlabel("$|u|$","Interpreter","latex","FontSize",20)
        set(gca,'LineWidth',1)
%         legend("M_{1,h}^k","M_{2,h}^k","M_{3,h}^k")
    end
%%  附录函数
    %% dispord：离散内积函数
    function I = dispord(u,v,h)
        I = (h*sum(u.*conj(v),1));
    end
    %% DS: 谱微分矩阵
    function [Lam1,Lam2] = DS(m,L)
        lambda = 2*pi/L;
        r1 = (zeros(m,1));  
        r1(1:m/2) = 0:m/2-1; r1(m/2+2:m) = -m/2+1:-1;
        r2 = r1; r2(m/2+1) = m/2;
        Lam1 = (1i * lambda * r1);
        Lam2 = (1i * lambda * r2).^2;
    end
    %% fun: 基于快速傅里叶变换的微分矩阵
    function y = dfft(u,d)
        y = ifft(d.*fft(u)); 
    end
%     %% fun: 基于快速傅里叶变换的微分矩阵
%     function y = fun(u,v)
%         y = u; 
%     end
end