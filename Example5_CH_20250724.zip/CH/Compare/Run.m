clear;clc
format short e
m = 2048;n = 1e4;
q = 2;pic = 1;
for s = 1
    tic
    if s == 5
        [u,E,M,P,H,x,t] = SAV_RK_Newton(m,n,3,q,pic);
    elseif s == 6
        [u,E,M,P,H,x,t] = SAV_CN(m,n,1,q,pic);
    else
        for i = 1:length(n)
            [u,E,M,P,H,x,t] = IEQ_RK(m,n,s,q,pic);
        end
    end
    CPU_time(s,i) = toc;
    P1(:,s) = P;Err_P(s,i) = max(abs(P-P(1)));
    M1(:,s) = M;Err_M(s,i) = max(abs(M-M(1)));
    E1(:,s) = E;Err_E(s,i) = max(abs(E-E(1)));
    H1(:,s) = H;Err_H(s,i) = max(abs(H-H(1)));
end
Scheme = ["IEQ_RK1";"IEQ_RK2";"IEQ_RK3";"IEQ_RK4";"SAV_RK3";"SAV_CN"];
Table = table(Scheme,Err_P,Err_M,Err_E,Err_H,CPU_time);
save("Table.mat","Table")
%% 
fig = figure(7);
plot(t,abs(H1-H1(1,:)),"--","LineWidth",2)
xlabel("$t_k$","Interpreter","latex","FontSize",20)
% ylabel("$E_{H}^k$","Interpreter","latex","FontSize",20)
title("$|H_{h}^k-H_h^0|$ ","Interpreter","latex","FontSize",20)
legend("IEQ-RK1","IEQ-RK2","IEQ-RK3","IEQ-RK4","SAV-RK3","SAV-CN","Interpreter","latex","Location","best")
set(gca,'LineWidth',1,'YScale','log','FontSize',15,'FontName',"Times New Roman")
grid on
savefig(fig,"fig2_7.fig")
saveas(fig,"fig2_7.eps","epsc")
fig = figure(8);
plot(t,abs(E1-E1(1,:)),"--","LineWidth",2)
xlabel("$t_k$","Interpreter","latex","FontSize",20)
% ylabel("$E_{H}^k$","Interpreter","latex","FontSize",20)
title(" $|E_{h}^k-H_h^0|$ ","Interpreter","latex","FontSize",20)
legend("IEQ-RK1","IEQ-RK2","IEQ-RK3","IEQ-RK4","SAV-RK3","SAV-CN","Interpreter","latex","Location","best")
set(gca,'LineWidth',1,'YScale','log','FontSize',15,'FontName',"Times New Roman")
grid on
savefig(fig,"fig2_8.fig")
saveas(fig,"fig2_8.eps","epsc")
fig = figure(9);
plot(t,abs(P1-P1(1,:)),"--","LineWidth",2)
xlabel("$t_k$","Interpreter","latex","FontSize",20)
% ylabel("$E_{M_1}^k$","Interpreter","latex","FontSize",20)
title("$|M_{1,h}^k-M_{1,h}^0|$ ","Interpreter","latex","FontSize",20)
legend("IEQ-RK1","IEQ-RK2","IEQ-RK3","IEQ-RK4","SAV-RK3","SAV-CN","Interpreter","latex","Location","best")
set(gca,'LineWidth',1,'YScale','log','FontSize',15,'FontName',"Times New Roman")
grid on
savefig(fig,"fig2_9.fig")
saveas(fig,"fig2_9.eps","epsc")
fig = figure(10);
plot(t,abs(M1-M1(1,:)),"--","LineWidth",2)
xlabel("$t_k$","Interpreter","latex","FontSize",20)
% ylabel("$E_{M_2}^k$","Interpreter","latex","FontSize",20)
set(gca,'YScale','log') 
title("$|M_{2,h}^k-M_{2,h}^0|$","Interpreter","latex","FontSize",20)
legend("IEQ-RK1","IEQ-RK2","IEQ-RK3","IEQ-RK4","SAV-RK3","SAV-CN","Interpreter","latex","Location","best")
set(gca,'LineWidth',1,'YScale','log','FontSize',15,'FontName',"Times New Roman")
grid on
savefig(fig,"fig2_10.fig")
saveas(fig,"fig2_10.eps","epsc")


