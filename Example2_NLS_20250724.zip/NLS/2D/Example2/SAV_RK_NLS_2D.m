function [z,E,H,M,x,y,t] = SAV_RK_NLS_2D(s,q)
%UNTITLED3 此处提供此函数的摘要
%   此处提供详细说明
    bar = waitbar(0,'please wait...');
    %% 网格划分
    %% 真解和初边值条件
    if q == 2
        Z = @(x,y) (1+sin(x)).*(2+sin(y));
        m = 128;n = 128;p = 2e3;
        xa = 0;xb = 2*pi;Lx = abs(xb-xa);hx = Lx/m;x = xa:hx:xb;x = x';
        ya = 0;yb = 2*pi;Ly = abs(yb-ya);hy = Ly/n;y = xa:hy:xb;
        ta = 0;tb = 0.2;ht = abs(tb-ta)/p;t = ta:ht:tb;r = 1;
        ep = 0.5e-9;% 允许最大误差精度
    elseif q == 1
        Z = @(x,y) 2/sqrt(pi)*exp(-x.^2-y.^2) ;
        m = 256;n = 256;p = 1e3;
        xa = -10;xb = 10;Lx = abs(xb-xa);hx = Lx/m;x = xa:hx:xb;x = x';
        ya = -10;yb = 10;Ly = abs(yb-ya);hy = Ly/n;y = xa:hy:xb;
        ta = 0;tb = 10;ht = abs(tb-ta)/p;t = ta:ht:tb;r = 1;
        ep = 1e-10;% 允许最大误差精度
    end
    z = zeros(m+1,n+1,p+1);z(:,:,1) = Z(x,y);
    u(:,1) = reshape(z(1:m,1:n,1),[],1);
%%  空间方向  
    %% 谱微分矩阵对应向量
    [~,Lam2x] = DS(m,Lx);[~,Lam2y] = DS(n,Ly);
    Lam2 = kron(ones(n,1),Lam2x)+kron(Lam2y,ones(m,1));
    Lam0 = 1i*ht*Lam2;
%% 时间方向
    %% 高斯配置-隐式龙格库塔方法
    if s == 1
        A = 1/2;
        b = 1;
    elseif s == 2
        A = [1/4 1/4-sqrt(3)/6;1/4+sqrt(3)/6 1/4];
        b = [1/2 1/2];
    elseif s == 3
        A = [5/36 2/9-sqrt(15)/15 5/36-sqrt(15)/30;
            5/36+sqrt(15)/24 2/9 5/36-sqrt(15)/24;
            5/36+sqrt(15)/30 2/9+sqrt(15)/15 5/36];
        b = [5/18 4/9 5/18];
    elseif s == 4
        A = double([sqrt(sym(30))/144 + sym(1/8), sqrt(sym(30))/144 - (sqrt(sym(42))*sqrt(15 - 2*sqrt(sym(30))))/168 - (sqrt(sym(35))*sqrt(15 - 2*sqrt(sym(30))))/105 + sym(1/8), (23*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(6*sqrt(sym(30)) + 45)/42 - sqrt(sym(30))/144 + sqrt(70*sqrt(sym(30)) + 525)/1470 + (5*sqrt(84*sqrt(sym(30)) + 630))/2352 + sym(1/8), (23*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(6*sqrt(sym(30)) + 45)/42 - sqrt(sym(30))/144 - sqrt(70*sqrt(sym(30)) + 525)/1470 - (5*sqrt(84*sqrt(sym(30)) + 630))/2352 + sym(1/8); (sqrt(sym(35))*sqrt(15 - 2*sqrt(sym(30))))/105 + (sqrt(sym(42))*sqrt(15 - 2*sqrt(sym(30))))/168 + sqrt(sym(30))/144 + sym(1/8), sqrt(sym(30))/144 + sym(1/8), sqrt(6*sqrt(sym(30)) + 45)/42 - sqrt(sym(30))/144 - (23*sqrt(20*sqrt(sym(30)) + 150))/1680 + sqrt(70*sqrt(sym(30)) + 525)/1470 + (5*sqrt(84*sqrt(sym(30)) + 630))/2352 + sym(1/8), sqrt(6*sqrt(sym(30)) + 45)/42 - sqrt(sym(30))/144 - (23*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(70*sqrt(sym(30)) + 525)/1470 - (5*sqrt(84*sqrt(sym(30)) + 630))/2352 + sym(1/8); sqrt(sym(30))/144 + sqrt(6*sqrt(sym(30)) + 45)/84 - (13*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(70*sqrt(sym(30)) + 525)/420 - sqrt(84*sqrt(sym(30)) + 630)/336 + sym(1/8), sqrt(sym(30))/144 - sqrt(6*sqrt(sym(30)) + 45)/84 + (13*sqrt(20*sqrt(sym(30)) + 150))/1680 - sqrt(70*sqrt(sym(30)) + 525)/420 - sqrt(84*sqrt(sym(30)) + 630)/336 + sym(1/8), sym(1/8) - sqrt(sym(30))/144, (sqrt(sym(42))*sqrt(2*sqrt(sym(30)) + 15))/168 - (sqrt(sym(35))*sqrt(2*sqrt(sym(30)) + 15))/105 - sqrt(sym(30))/144 + sym(1/8); sqrt(sym(30))/144 + sqrt(6*sqrt(sym(30)) + 45)/84 - (13*sqrt(20*sqrt(sym(30)) + 150))/1680 + sqrt(70*sqrt(sym(30)) + 525)/420 + sqrt(84*sqrt(sym(30)) + 630)/336 + sym(1/8), sqrt(sym(30))/144 - sqrt(6*sqrt(sym(30)) + 45)/84 + (13*sqrt(20*sqrt(sym(30)) + 150))/1680 + sqrt(70*sqrt(sym(30)) + 525)/420 + sqrt(84*sqrt(sym(30)) + 630)/336 + sym(1/8), (sqrt(sym(35))*sqrt(2*sqrt(sym(30)) + 15))/105 - (sqrt(sym(42))*sqrt(2*sqrt(sym(30)) + 15))/168 - sqrt(sym(30))/144 + sym(1/8), sym(1/8) - sqrt(sym(30))/144]);
        b = double([sqrt(sym(30))/72 + sym(1/4), sqrt(sym(30))/72 + sym(1/4), sym(1/4) - sqrt(sym(30))/72, sym(1/4) - sqrt(sym(30))/72]);
    end
    %% 循环求解过程所用矩阵系数
    J = matlabFunction(reshape((eye(s)-sym("x")*A)\eye(s),[],1));
    F = reshape(J(Lam0),[],s);
    %% 初始守恒律
    E = zeros(1,p+1);V = E;H = E;M = E;
    D2U1 = dfft2(u(:,1),Lam2);
    M(1) = dispord(u(:,1),u(:,1),hx);
    E(1) = -dispord(u(:,1),D2U1,hx)-r/2*dispord(u(:,1).^2,u(:,1).^2,hx);
    H(1) = E(1);
    V(1) = sqrt(-dispord(u(:,1),D2U1,hx));
    tic
    for k = 1:p
        str=['计算中...',num2str(100*(k-1)/p),'%','(',num2str((k-1)),'/',num2str(p),')',';','当前耗时',num2str(toc),'秒'];    % 百分比形式显示处理进程,不需要删掉这行代码就行
        waitbar((k-1)/p,bar,str)                       % 更新进度条bar，配合bar使用
        %% 初始值
        U0 = u(:,k);v0 = V(k);
        f0 = 1i*(dfft2(U0,Lam2)+r*abs(U0.^2).*U0);
        %% 主要迭代变量
        f = kron(ones(1,s),f0);g = zeros(s,1);
        while 1
            U = U0+ht*f*A';
            M_temp = -dispord(U,dfft2(U,Lam2),hx);
            V_temp = sqrt(M_temp);
            Q = (abs(U.^2).*U)./V_temp;
            g = real(dispord(Q,f,hx));
            v = v0+ht*A*g';
            w = f-1i*(dfft2(U,Lam2)+r*Q.*v');
            %% 矩阵求解
            err = -reshape(ifft2(reshape(sum(F.*kron(ones(s,1),reshape(fft2(reshape(w,m,n,s)),[],s)),2),m,n,s)),[],s);
            f = f+err;
            %% 循环跳出判断
            if max(abs(err)) <= ep
                break;
            end
        end
        u(:,k+1) = U0+ht*f*b';
        z(1:m,1:n,k+1) = reshape(u(:,k+1),m,n);z(:,end,k+1) = z(:,1,k+1);z(end,:,k+1) = z(1,:,k+1);
        V(k+1) = v0+ht*b*g';
        M(k+1) = dispord(u(:,k+1),u(:,k+1),hx);
        E(k+1) = -dispord(u(:,k+1),dfft2(u(:,k+1),Lam2),hx)-V(k+1)^2+E(1);
        H(k+1) = -dispord(u(:,k+1),dfft2(u(:,k+1),Lam2),hx)-r/2*dispord(u(:,k+1).^2,u(:,k+1).^2,hx);
    end
    close(bar)
%%  附录函数
    %% dispord：离散内积函数
    function I = dispord(u,v,h)
        I = (h^2*sum(u.*conj(v)));
    end
    %% DS: 谱微分矩阵
    function [Lam1,Lam2] = DS(m,L)
        lambda = 2*pi/L;
        r1 = (zeros(m,1));  
        r1(1:m/2) = 0:m/2-1; r1(m/2+2:m) = -m/2+1:-1;
        r2 = r1; r2(m/2+1) = m/2;
        Lam1 = (1i * lambda * r1);
        Lam2 = (1i * lambda * r2).^2;
    end
    %% fun: 基于快速傅里叶变换的微分矩阵
    function y = dfft2(u,d)
        [~,row] = size(u);
        u = reshape(u,m,n,row);
        u1 = ifft2(reshape(d.*reshape(fft2(u),[],row),m,n,[])); 
        y = reshape(u1,[],row);
    end
end