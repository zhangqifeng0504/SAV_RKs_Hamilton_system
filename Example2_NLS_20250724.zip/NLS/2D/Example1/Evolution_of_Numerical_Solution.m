clear;clc
format short e
q = 1;s = 3;
[z,E,H,M,x,y,t] = SAV_RK_NLS_2D(s,q);
%% 
[~,~,p] = size(z);z_max = max(max(max(abs(z))));
% 设置视频参数
videoName = strcat('NLS_2D_Case', num2str(q), '.mp4');
frameRate = 10;  % 10 fps = 每帧0.1秒
videoObj = VideoWriter(videoName, 'MPEG-4');
videoObj.FrameRate = frameRate;
videoObj.Quality = 95;  % 95%质量更可靠

% 创建图形窗口并锁定尺寸
fig = figure('Units', 'pixels', 'Position', [100, 100, 1920, 1080], ...
             'Color', 'w', 'Renderer', 'opengl', ...
             'Resize', 'off'); % 禁止调整大小

% 初始绘制
meshHandle = mesh(x, y, abs(z(:,:,1))');
titleHandle = title("", "Interpreter", "latex", "FontSize", 20);
xlabel("$x$", "Interpreter", "latex", "FontSize", 20);
ylabel("$y$", "Interpreter", "latex", "FontSize", 20);
zlabel(" $|u(x,y,t)|$ ", "Interpreter", "latex", "FontSize", 20);
colorbar;
colormap jet;
shading interp;
camlight;
lighting phong;
view(3);
axis tight;
set(gca, 'LineWidth', 1, 'FontSize', 15, 'FontName', "Times New Roman");

% 确保图形完全渲染并固定尺寸
drawnow;
set(fig, 'Position', [100, 100, 1920, 1080]); % 再次确认尺寸

% 打开视频文件
open(videoObj);

% 时间索引选择
t_idex = 1:p;

% 记录第一帧尺寸用于验证
firstFrameSize = [];

for i = t_idex
    % 更新数据
    set(meshHandle, 'ZData', abs(z(:,:,i))');
    
    % 更新z轴范围
    if i <= p/20
        zlim([0 z_max]);
    else
        zlim([0 0.5]);
    end
    
    % 更新标题
    set(titleHandle, 'String', strcat("t = ", num2str(t(i))));
    
    % 刷新图形
    drawnow;
    
    % 捕获整个图形窗口
    frame = getframe(fig);
    
    % 检查帧尺寸
    if isempty(firstFrameSize)
        firstFrameSize = size(frame.cdata);
        fprintf('帧尺寸: %d x %d\n', firstFrameSize(2), firstFrameSize(1));
        
        % 验证尺寸
        if firstFrameSize(1) ~= 1080 || firstFrameSize(2) ~= 1920
            warning('实际帧尺寸(%dx%d)与预期(1920x1080)不符，自动调整', ...
                    firstFrameSize(2), firstFrameSize(1));
        end
    end
    
    % 写入视频
    writeVideo(videoObj, frame);
    
    % 每帧显示0.1秒
    pause(0.1);
end

% 关闭视频文件
close(videoObj);

fprintf('视频已成功保存为: %s (%.1f秒, %d帧, %.1f秒/帧)\n', ...
        videoName, length(t_idex)*0.1, length(t_idex), 0.1);