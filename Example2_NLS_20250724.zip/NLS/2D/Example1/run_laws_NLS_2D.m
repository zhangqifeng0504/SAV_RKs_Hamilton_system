clear;clc
format short e
q = 1;
for s = 1:4
    tic
    [z,E,H,M,x,y,t] = SAV_RK_NLS_2D(s,q);
    CPU_time(s,1) = toc;
    M1(:,s) = M;Err_M(s,1) = max(abs(M-M(1)));
    E1(:,s) = E;Err_E(s,1) = max(abs(E-E(1)));
    H1(:,s) = E;Err_H(s,1) = max(abs(H-H(1)));
end
%% 数值解曲面图
fig = figure(1);
mesh(x,y,abs(z(:,:,1))')
xlabel("$x$","Interpreter","latex","FontSize",20)
ylabel("$y$","Interpreter","latex","FontSize",20)
zlabel(" $|u(x,y,t)|$ ","Interpreter","latex","FontSize",20)
set(gca,'LineWidth',1,'FontSize',15,'FontName',"Times New Roman")
colorbar;colormap jet
shading interp % 美化1
camlight       % 美化2
lighting phong
savefig(fig,strcat("fig3_1_2D_",num2str(q),".fig"))
saveas(fig,strcat("fig3_1_2D_",num2str(q)),"epsc")

fig = figure(5);
mesh(x,y,abs(z(:,:,1e2+1))')
zlim([0 0.5])
xlabel("$x$","Interpreter","latex","FontSize",20)
ylabel("$y$","Interpreter","latex","FontSize",20)
zlabel(" $|u(x,y,t)|$ ","Interpreter","latex","FontSize",20)
set(gca,'LineWidth',1,'FontSize',15,'FontName',"Times New Roman")
colorbar;colormap jet
shading interp % 美化1
camlight       % 美化2
lighting phong
savefig(fig,strcat("fig3_5_2D_",num2str(q),".fig"))
saveas(fig,strcat("fig3_5_2D_",num2str(q)),"epsc")

fig = figure(2);
mesh(x,y,abs(z(:,:,end))')
zlim([0 0.5])
xlabel("$x$","Interpreter","latex","FontSize",20)
ylabel("$y$","Interpreter","latex","FontSize",20)
zlabel(" $|u(x,y,t)|$ ","Interpreter","latex","FontSize",20)
set(gca,'LineWidth',1,'FontSize',15,'FontName',"Times New Roman")
colorbar;colormap jet
shading interp % 美化1
camlight       % 美化2
lighting phong
savefig(fig,strcat("fig3_2_2D_",num2str(q),".fig"))
saveas(fig,strcat("fig3_2_2D_",num2str(q)),"epsc")
%% 守恒量误差图
fig = figure(3);
plot(t,abs(H1-H1(1,:)),"--","LineWidth",2)
xlabel("$t_k$","Interpreter","latex","FontSize",20)
title(" $|H_{h}^k-H_{h}^0|$ ","Interpreter","latex","FontSize",20)
legend("$s = 1$","$s = 2$","$s = 3$","$s = 4$","Interpreter","latex","Location","best")
set(gca,'LineWidth',1,'YScale','log','FontSize',15,'FontName',"Times New Roman")
grid on
savefig(fig,strcat("fig3_3_2D_",num2str(q),".fig"))
saveas(fig,strcat("fig3_3_2D_",num2str(q)),"epsc")

fig = figure(4);
plot(t,abs(E1-E1(1,:)),"--","LineWidth",2),
xlabel("$t_k$","Interpreter","latex","FontSize",20)
title("$|E_{h}^k-H_h^0|$ ","Interpreter","latex","FontSize",20)
legend("$s = 1$","$s = 2$","$s = 3$","$s = 4$","Interpreter","latex","Location","best")
set(gca,'LineWidth',1,'YScale','log','FontSize',15,'FontName',"Times New Roman")
grid on
savefig(fig,strcat("fig3_4_2D_",num2str(q),".fig"))
saveas(fig,strcat("fig3_4_2D_",num2str(q)),"epsc")

fig = figure(6);
plot(t,abs(M1-M1(1,:)),"--","LineWidth",2)
xlabel("$t_k$","Interpreter","latex","FontSize",20)
% ylabel("$Err_{M_2}^k$","Interpreter","latex","FontSize",20)
set(gca,'YScale','log') 
title(" $|M_{2,h}^k-M_{2,h}^0|~{\rm with}~\mathbf{B} = \mathbf{I}_m$ ","Interpreter","latex","FontSize",20)
legend("$s = 1$","$s = 2$","$s = 3$","$s = 4$","Interpreter","latex","Location","best")
set(gca,'LineWidth',1,'YScale','log','FontSize',15,'FontName',"Times New Roman")
grid on
savefig(fig,strcat("fig3_6_2D_",num2str(q),".fig"))
saveas(fig,strcat("fig3_6_2D_",num2str(q)),"epsc")