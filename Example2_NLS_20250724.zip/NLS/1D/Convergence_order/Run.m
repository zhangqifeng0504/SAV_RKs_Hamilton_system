clear;clc
format short e
m = 1e3;
n = (150:10:200)';
n = 10.^(1:4)';
q = 2;pic = 0;
for s = 1:4
for i = 1:length(n)
    tic
    [u,Err,E,M,P,x,t,flag] = SAV_RK_Newton(m,n(i),s,q,pic);
    MaxErr(i,s) = max(max(Err));
    CPU_time(i,s) = toc;
    subplot(4,length(n),i+4*(s-1))
    plot(t(2:end)-t(1),flag,"g.","LineWidth",1,"MarkerSize",10)
    ylabel("Iterations")
    xlabel("$t_k$","Interpreter","latex")
    title(strcat("$s = $",num2str(s),"$,\;\tau = $",num2str(1./n(i))),"Interpreter","latex")
    set(gca,'LineWidth',1,'FontName',"Times New Roman","FontSize",15)
    % set(gca,'xticklabel',[])
    CPU_time(i,s) = toc;
end
Ord(:,s) = [0;log2(MaxErr(1:end-1,s)./MaxErr(2:end,s))./(log2(n(2:end)./n(1:end-1)))];
end
Table = table(MaxErr,Ord,CPU_time)
save("Table.mat","Table")